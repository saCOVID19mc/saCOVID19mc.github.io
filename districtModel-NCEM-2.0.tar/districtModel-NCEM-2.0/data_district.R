#Data Wrangling

#function to read in all sheets in a workbook
read_excel_allsheets <- function(filename, tibble = FALSE) {
  sheets <- readxl::excel_sheets(filename)
  x <- lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  if(!tibble) x <- lapply(x, as.data.frame)
  names(x) <- sheets
  x
}


pop = read_excel("district_population.xlsx") #district population
districts = read_excel("districts.xlsx") #district numbers and codes
parameters = read_excel_allsheets("Parameters.xlsx")$parameters
provparam = read_excel_allsheets("Parameters.xlsx")$prov
district_capacity = read_excel("district_capacity.xlsx") #placeholder capacity
prov_R0g = read_excel("provR0google.xlsx") #NICD R0, L5, google mobility increase in contacts
seeddata = read_excel("district_seeds.xlsx") #for districts in which infection had not yet spread at the start of the simulation
infcases = read_excel("infcases.xlsx") # reported infectious cases at the start of the simulation
peakadm = read_excel("Provincial peaks for admissions.xlsx", sheet = "input")


#read in placeholder (not data-based) movement matrices and arrange by district code
readMvt <- function(fname) {
  read_excel(fname) %>% 
    select(districts$Code) %>% 
    as.matrix()
}
mvtL0 = readMvt("Movement Matrices/movMatL0.xlsx")
mvtpreL5 = readMvt("Movement Matrices/movMatBeforeL5.xlsx")
mvtL5 = readMvt("Movement Matrices/movMatL5.xlsx")
mvtL4 = readMvt("Movement Matrices/movMatL4.xlsx")
mvtL3_12 = readMvt("Movement Matrices/movMatL3_12.xlsx")
mvtL3_345 = readMvt("Movement Matrices/movMatL3_345.xlsx")
mvtL2 = readMvt("Movement Matrices/movMatL2.xlsx")

#Check
mvtdiags<-cbind(diag(mvtL0), diag(mvtpreL5), diag(mvtL5), diag(mvtL4), diag(mvtL3_12), diag(mvtL3_345), diag(mvtL2))/diag(mvtL0)
par(mfrow=c(1,1)); matplot(t(mvtdiags), ty="l"); lines(colMeans((mvtdiags)), lwd=4)

#Correct Province Order (for Province/District reference)
P<-list()
P[[1]]<-which(districts$Province=="EC")
P[[2]]<-which(districts$Province=="FS")
P[[3]]<-which(districts$Province=="GP")
P[[4]]<-which(districts$Province=="KZN")
P[[5]]<-which(districts$Province=="LP")
P[[6]]<-which(districts$Province=="MP")
P[[7]]<-which(districts$Province=="NC")
P[[8]]<-which(districts$Province=="NW")
P[[9]]<-which(districts$Province=="WC")
names(P)<-c(sort(unique(districts$Province)))


#check and order datasets
capacity <- districts %>% 
  select(-No.) %>% 
  left_join(district_capacity, by=c('Code')) %>% 
  arrange(No.)


infcases <- infcases %>% 
   left_join(districts, by=c('No.')) %>% 
   arrange(No.)

disR0g <- districts %>% 
  left_join(prov_R0g, by=c('Province'))

pts_peak <- districts %>% 
  left_join(peakadm, by=c('Province'))


seeddata <- seeddata %>% 
  select(Date, districts$Code) %>% 
  mutate(t = (as.Date(Date)-as.Date("2020-03-01"))/365
  )



#Order check
print(
all.equal(districts$Code,
          colnames(mvtL0), 
          colnames(mvtpreL5), 
          colnames(mvtL5), 
          colnames(mvtL4), 
          colnames(mvtL3), 
          pop$Code, 
          capacity$Code, 
          colnames(cases),
          disR0g$Code,
          pts_peak$Code,
          colnames(seeddata[,2:53])
))
