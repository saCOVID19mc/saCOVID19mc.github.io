# National COVID-19 Epi Model - District Model Code

The code in this repository runs the district-level model used to generate results for the national and provincial long-term reports released on 19 May. 
Information on the structure and logic of the code are summarized in the [NCEM Provincial Model Code Guide](http://sacovid19mc.github.io/ncemProvincialCodeGuide.pdf). Additional information on the model equations, variables, and parameters are summarized in the [National COVID Epi Model: Provincial model - Supplementary information](http://sacovid19mc.github.io/supplementaryInformation).

## Set-up

To run the code in this repository, you will require the following software:

- [R](http://r-project.org/)
- [R studio](https://rstudio.com/)
- a C compiler, e.g., [gcc](https://gcc.gnu.org/)

Once these are installed, the script <./packages.R> can be run from within R studio to install any required R packages that are not already installed on your computer.

Depending on the number of cores you have available, you may want to change the number of cores used for stochastic runs on line 32. If you have limited computational power, you may also want to reduce the number of iterations for stochasitc sampling.

An example session for which the code successfully runs has the following session information:

```
R version 4.0.3 (2020-10-10)
Platform: x86_64-apple-darwin17.0 (64-bit)
Running under: macOS Catalina 10.15.7

Matrix products: default
BLAS:   /System/Library/Frameworks/Accelerate.framework/Versions/A/Frameworks/vecLib.framework/Versions/A/libBLAS.dylib
LAPACK: /Library/Frameworks/R.framework/Versions/4.0/Resources/lib/libRlapack.dylib

locale:
[1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8

attached base packages:
[1] parallel  stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
 [1] doParallel_1.0.16 iterators_1.0.13  foreach_1.5.1     argparser_0.7.1  
 [5] JuliaCall_0.17.4  EnvStats_2.4.0    openxlsx_4.2.4    readxl_1.3.1     
 [9] glue_1.4.2        diffeqr_1.1.1     deSolve_1.28      adaptivetau_2.2-3
[13] crayon_1.4.1      forcats_0.5.1     stringr_1.4.0     dplyr_1.0.7      
[17] purrr_0.3.4       readr_2.0.1       tidyr_1.1.3       tibble_3.1.3     
[21] ggplot2_3.3.5     tidyverse_1.3.1   pacman_0.5.1     

loaded via a namespace (and not attached):
 [1] Rcpp_1.0.7       lubridate_1.7.10 assertthat_0.2.1 utf8_1.2.2       R6_2.5.0        
 [6] cellranger_1.1.0 backports_1.2.1  reprex_2.0.1     httr_1.4.2       pillar_1.6.2    
[11] rlang_0.4.11     rstudioapi_0.13  munsell_0.5.0    tinytex_0.33     broom_0.7.9     
[16] compiler_4.0.3   modelr_0.1.8     xfun_0.25        pkgconfig_2.0.3  tidyselect_1.1.1
[21] codetools_0.2-18 fansi_0.5.0      tzdb_0.1.2       dbplyr_2.1.1     withr_2.4.2     
[26] grid_4.0.3       jsonlite_1.7.2   gtable_0.3.0     lifecycle_1.0.0  DBI_1.1.1       
[31] magrittr_2.0.1   scales_1.1.1     zip_2.2.0        cli_3.0.1        stringi_1.7.3   
[36] fs_1.5.0         xml2_1.3.2       ellipsis_0.3.2   generics_0.1.0   vctrs_0.3.8     
[41] tools_4.0.3      hms_1.1.0        yaml_2.2.1       colorspace_2.0-2 rvest_1.0.1     
[46] knitr_1.33       haven_2.4.3    
```

## Results
Owing to restrictions on sharing mobile device-related data and hospital capacity data, *placeholder* matrices and capacity data have been shared on the repository. Therefore the results presented in reports will not be able to be replicated directly from the code. Users may replace the files in <./Movement Matrices> and <./district_capacity.xlsx> with own data. 

## Contact

If there are any queries regarding the model or the code, please contact us via: <info@sacovid19mc.co.za>.
