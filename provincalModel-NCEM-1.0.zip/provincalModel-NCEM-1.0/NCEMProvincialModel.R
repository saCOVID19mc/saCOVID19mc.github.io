#National COVID-19 Epi Model (NCEM)
#https://www.nicd.ac.za/diseases-a-z-index/covid-19/surveillance-reports/
#Supporting documents: Github repository

#Model Characteristics: 
#Spatial Granularity: Provincial  
#Disease: Covid-19
#Time Frame (Data): 2020-03-20 - 2021-03-20
#Notes: The model structure is written in R. 
      # Simulations are run in R with a C compiler. 

source('./packages.R') # install required packages (if not installed) 
library(deSolve)
library(adaptivetau)
library(ggplot2)
library(readxl)
library(EnvStats)
library(openxlsx)
library(rstudioapi)
library(doParallel)

#function to read in all sheets in a workbook
read_excel_allsheets <- function(filename, tibble = FALSE) {
  sheets <- readxl::excel_sheets(filename)
  x <- lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  if(!tibble) x <- lapply(x, as.data.frame)
  names(x) <- sheets
  x
}

numCores <-8 #Set number of cores for execution of stochastic runs in parallel
n_iterations <- 10000 #set no. of iterations for stochastic runs
# ************************************************************************************* #
#Set working directory, read in C files, load packages, start up model dimensions
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) # set wd to source file
system("R CMD SHLIB eq0.c")     # compiles c code
dyn.load("eq0.so")              # loads compiled code to memory (.so - OS X, .dll - Windows)

N<-9   # number of patches
B<-15   # number of variables per patch
A<-23  # number of transitions per patch
V<-N*B # total number of variables
L<-N*A #total number of transitions
sday<-20
startyear=sday/365 # starting year of simulation 0=2020-03-01
tyears<-(52*7)/365 # total years of simulation 1
dtout<-1/365 # output timestep
tsteps<-round(tyears/dtout) # number of time steps
time<-startyear+seq(0,tyears,dtout) # time vector

# Call C function from eq0.so in R
EQ<-function(L, N, oldeq, transit,transitionsiu1,transitionsiu2,transitionsiv1,transitionsiv2){
  len<-length(oldeq)
  .C("EQ",
     as.integer(L),
     as.integer(N),
     as.double(oldeq),
     as.double(transit),
     as.integer(transitionsiu1),
     as.integer(transitionsiu2),
     as.integer(transitionsiv1),
     as.integer(transitionsiv2),
     as.double(vector("double",length = len))
  )[[9]]
  
}

# ************************************************************************************* #
# import data
# ************************************************************************************* #
alldata = read_excel_allsheets("za_data.xlsx")
pvxy<-alldata$dem  
parameters = alldata$parameters[,c(1,3,4,5)]
severity = read_excel_allsheets("prov_severity.xlsx")
sev<-severity$Sheet2
casespub <- readr::read_csv("https://raw.githubusercontent.com/dsfsi/covid19za/master/data/covid19za_provincial_cumulative_timeline_confirmed.csv")
casesp<-as.data.frame(casespub[,c(1,3:11)])
imp<-alldata$imp; imp[is.na(imp)]=0 


# ************************************************************************************* #
# define variables
# ************************************************************************************* #
# Covid-19 Variables
# 1=S: uninfected non-immune
# 2=E: infected & exposed
# 3=Ia: asymptomatic
# 4=Ip: pre-symptomatic and infectious 
# 5=Im: mild and infectious
# 6=Is: severe and infectious
# 7=H1: severe treated in general hospital (non-ICU)
# 8=H2: critical entry into general hospital (non-ICU)
# 9=ICU1: critical destined to die  (ICU) 
# 10=ICU2: critical destined to be discharged  (ICU)
# 11=H3:  critical stepdown from ICU to general hosptial (non-ICU)
# 12=Removed: holds non-infectious cases, recoveries and discharges
# 13=Died: holds Deaths
# 14=Imdet Counter: Positive confirmed mild cases | test seeking
# 15=Isdet Counter: Positive confirmed severe/critical cases | hospitalisation


covpop<-c(1:12) #Living population

# ************************************************************************************* #
# define indices
# ************************************************************************************* #
varind<-matrix(0,nrow=B,ncol=N)
traind<-matrix(0,nrow=A,ncol=N)
for (n in 1:N){
  for (b in 1:B){
    varind[b,n]<-(n-1)*B+b
  }
  for (a in 1:A){
    traind[a,n]<-(n-1)*A+a
  }
}

# ************************************************************************************* #
# define transitions
# ************************************************************************************* #
# first transition is given without index
transitions =ssa.maketrans(V,rbind(varind[4,1], +1)) # example
for (n in 1:N){
  #Imports
  transitions[traind[1,n]]<-ssa.maketrans(V,rbind(varind[1,n], 0,varind[5,n], +1)) # imported cases -> Im=5 
  transitions[traind[2,n]]<-ssa.maketrans(V,rbind(varind[1,n], 0,varind[6,n], +1)) # imported cases -> Is=6 
  transitions[traind[3,n]]<-ssa.maketrans(V,rbind(varind[1,n], 0,varind[8,n], +1)) # imported cases -> H2=8
  #Incidence
  transitions[traind[4,n]]<-ssa.maketrans(V,rbind(varind[1,n], -1,varind[2,n],+1)) # incidence S to E 
  transitions[traind[5,n]]<-ssa.maketrans(V,rbind(varind[2,n], -1,varind[3,n],+1)) # incubation E to Ia  
  transitions[traind[6,n]]<-ssa.maketrans(V,rbind(varind[2,n], -1,varind[4,n],+1)) # incubation E to Ip 
  transitions[traind[7,n]]<-ssa.maketrans(V,rbind(varind[4,n], -1,varind[5,n],+1)) # mild infection Ip to Im
  transitions[traind[8,n]]<-ssa.maketrans(V,rbind(varind[4,n], -1,varind[6,n],+1)) # severe infection Ip to Is
  #Admission to Hospital
  transitions[traind[9,n]]<-ssa.maketrans(V,rbind(varind[6,n], -1,varind[7,n],+1)) # hosp severe Is to H1 (non-ICU)
  transitions[traind[10,n]]<-ssa.maketrans(V,rbind(varind[6,n], -1,varind[8,n],+1)) # hosp critical infection Is to H2 (non-ICU)
  transitions[traind[11,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[9,n],+1)) # icu critical infection (destined to die) H2 to ICU1
  transitions[traind[12,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[10,n],+1)) # icu critical infection (destined to be discharged) H2 to ICU2
  #Recovery
  transitions[traind[13,n]]<-ssa.maketrans(V,rbind(varind[3,n], -1,varind[12,n],+1)) # natural recovery Ia to R
  transitions[traind[14,n]]<-ssa.maketrans(V,rbind(varind[5,n], -1,varind[12,n],+1)) # natural recovery Im to R 
  #Hospital outcomes
  transitions[traind[15,n]]<-ssa.maketrans(V,rbind(varind[7,n], -1,varind[12,n],+1)) # severe discharged H1 to R
  transitions[traind[16,n]]<-ssa.maketrans(V,rbind(varind[7,n], -1,varind[13,n],+1)) # severe died H1 to D
  transitions[traind[17,n]]<-ssa.maketrans(V,rbind(varind[9,n], -1,varind[13,n],+1)) # critical died ICU1 to D
  transitions[traind[18,n]]<-ssa.maketrans(V,rbind(varind[10,n], -1,varind[11,n],+1)) # stepdown to non-ICU ICU2 to H3
  transitions[traind[19,n]]<-ssa.maketrans(V,rbind(varind[11,n], -1,varind[12,n],+1)) # critical discharged H3 to R
  #Detection Counters
  transitions[traind[20,n]]<-ssa.maketrans(V,rbind(varind[14,n], 0,varind[14,n], +1)) # inflow:  mild cases for testing -> Imdet=13 
  transitions[traind[21,n]]<-ssa.maketrans(V,rbind(varind[14,n], -1,varind[14,n], 0)) # outflow: confirmed mild cases  Imdet=13 ->
  transitions[traind[22,n]]<-ssa.maketrans(V,rbind(varind[15,n], 0,varind[15,n], +1)) # inflow:  severe/critical cases for testing -> Isdet=14  
  transitions[traind[23,n]]<-ssa.maketrans(V,rbind(varind[15,n], -1,varind[15,n], 0)) # outflow: confirmed severe/critical cases  Isdet=14 -> 
}

#Alternate formulation of transitions matrix (used in epimodel function)
transitions2<-NULL
for (i in 1: length(transitions)){
  transitions2<-rbind(transitions2,cbind(as.integer(names(transitions[[i]]))[1],as.integer(names(transitions[[i]]))[2], transitions[[i]][1], transitions[[i]][2]))
}
row.names(transitions2)<-NULL
transitionsiu1<-transitions2[,1]
transitionsiu2<-transitions2[,2]
transitionsiv1<-transitions2[,3]
transitionsiv2<-transitions2[,4]


# ************************************************************************************* #
# Set the parameters 
# ************************************************************************************* #
pars = {list(
  gamma1 = parameters[parameters$Parameter=="gamma1",2],  #1/non-infectious duration incubation 
  gamma2 = parameters[parameters$Parameter=="gamma2",2],  #1/infectious incubation duration
  r1= parameters[parameters$Parameter=="r1",2], # 1/dur infectiousness (asymptomatic)
  r2= parameters[parameters$Parameter=="r2",2], # 1/dur infectiousness (mild)
  mu =  parameters[parameters$Parameter=="mu",2], #death rate in ICU
  beta0 = rep( parameters[parameters$Parameter=="beta0",2],N), # effective no. of contacts (contact rate * probability of infection)
  R0 =  parameters[parameters$Parameter=="R0",2], # basic reproductive number
  taus= parameters[parameters$Parameter=="taus",2], # 1/trt seeking severe
  pa =  parameters[parameters$Parameter=="pa",2], # asymptomatic proportion of cases
  tauprog =  parameters[parameters$Parameter=="tauprog",2], # 1/ duration of progression of severe cases to critical 
  zeta1 = parameters[parameters$Parameter=="zeta1",2], #relative infectiousness of asymptomatic population
  r3= parameters[parameters$Parameter=="r3",2], #1/dur stay hospital (severe)
  r4= parameters[parameters$Parameter=="r4",2], #1/dur stay ICU (critical)
  pdetm= parameters[parameters$Parameter=="pdetm",2], #proportion of mild cases CONFIRMED upon trt seeking
  pdets= parameters[parameters$Parameter=="pdets",2], #proportion of severe cases CONFIRMED upon trt seeking
  deltam= parameters[parameters$Parameter=="deltam",2], #1/lead time to test result (mild)
  deltas= parameters[parameters$Parameter=="deltas",2], #1/lead time to test result (severe)
  r5= parameters[parameters$Parameter=="r5",2] #1/dur stay hosp (post critical)
 
);
} 
pars$pm<-as.numeric(sev[1,2:10])
pars$ps<-as.numeric(sev[2,2:10])
pars$pc<-as.numeric(sev[3,2:10])
pars$pd1<-0*as.numeric(sev[4,2:10])
pars$pd2<-1*as.numeric(sev[4,2:10]) #all deaths assumed to occur from critically ill patients
pars$durinf<-(pars$zeta1*pars$pa/pars$r1 + (1-pars$pa)/pars$gamma2 + (1-pars$pa)*pars$pm/pars$r2 + (1-pars$pa)*(1-pars$pm)/pars$taus) #compute duration of infection accounting for all levels of severity (annual units)

# ************************************************************************************* #
# Function to calculate inputs to transition rates
# ************************************************************************************* #

inputs<-function(parmal, scenario){
  #empty function: placeholder for additional model inputs
  }

# ************************************************************************************* #
#Set up matrices for rate function

# ************************************************************************************* #
# Function to calculate transition rates, given variables and parameters
# ************************************************************************************* #
covrates <- function(x, input, parmal, t,ti, scenario) {
  with(as.list(c( parmal, scenario)),
       {
         t_internal<-(ti-1)*dtout+t+startyear
         #Set up matrices
         pop<-popc<-c(rep(0,N))    # population sizes  
         foi<-c(rep(0,N))     # forces of infection 
         import<-seed<-c(rep(0,N))
         
         #scenario set up - dates reference 1/365 = 1 March 2020
         beta<-beta0
         #i1 Optimistic: social distancing after 5wk Level 5 restrictions and 1 month level 4 restrictions
         if (i2==1){
           beta<-(t_internal<27/365)*beta0 + (t_internal>=27/365)*(t_internal<62/365)*0.4*beta0+(t_internal>=62/365)*(t_internal<93/365)*0.65*beta0+(t_internal>=93/365)*0.8*beta0
           r4<-365/14
         }
         #Pessimistic: social distancing after 5wk Level 5 restrictions and 1 month level 4 restrictions
         if (i3==1){
           beta<-(t_internal<27/365)*beta0 + (t_internal>=27/365)*(t_internal<62/365)*0.6*beta0+(t_internal>=62/365)*(t_internal<93/365)*0.75*beta0+(t_internal>=93/365)*0.9*beta0
           r4<-365/18
         }
           
         
         for (n in 1:N){
         popc[n]<-sum(x[varind[covpop,n]])} # list of the variable indices for the human population

        tranrate<-matrix(0,nrow=N,ncol=A)   # transition rate matrix
         for (n in 1:N){
           foi<-(beta[n]*(zeta1*x[varind[3,n]]+x[varind[4,n]]+x[varind[5,n]]+x[varind[6,n]])/popc[n])
            
           if (t_internal<61/365) {
             import[n]<-approx(imp$Step, imp[,n+3], t_internal, rule=2)$y
           }
           
         
           tranrate[n,]<-c(   
             #Imports
             pm[n]*import[n], #  importation to Im       1
             ps[n]*import[n], #importation to Is 1       2
             (1-pm[n]-ps[n])*import[n], #importation to H2  3
             #Incidence
             foi*x[varind[1,n]],       # incidence S to E     4
             pa*gamma1*x[varind[2,n]],       # incubation E to Ia     5
             (1-pa)*gamma1*x[varind[2,n]],       # incubation E to Ip     6
             pm[n]*gamma2*x[varind[4,n]],       # mild infection Ip to Im       7
             (1-pm[n])*gamma2*x[varind[4,n]],       #  severe infection Ip to Is       8
             #Admission to hospital
             (1-(1-pm[n]-ps[n])/(1-pm[n]))*taus*x[varind[6,n]],       #  hosp severe Is to H1        9
             ((1-pm[n]-ps[n])/(1-pm[n]))*taus*x[varind[6,n]],   # hosp critical infection Is to H2 (non-ICU)    10
             pd2[n]*tauprog*x[varind[8,n]],       # icu critical infection (destined to die) H2 to ICU1    11
             (1-pd2[n])*tauprog*x[varind[8,n]],       # icu critical infection (destined to be discharged) H2 to ICU2   12
              #Recovery
             r1*x[varind[3,n]],       # natural recovery Ia (asymp) to R   13
             r2*x[varind[5,n]],         # natural recovery Im to R         14
             #Hospital outcomes
             (1-pd1[n])*r3*x[varind[7,n]],         # severe discharged H1 to R         15
             pd1[n]*r3*x[varind[7,n]], # severe died H1 to D         16
             mu*x[varind[9,n]],         #     critical died ICU1 to D   17
             r4*x[varind[10,n]],         #      stepdown to non-ICU ICU2 to H3  18
             r5*x[varind[11,n]],  #      critical discharged H3 to R   19
             #Detection
             pdetm[n]*pm[n]*gamma2*x[varind[4,n]], # inflow:  mild cases for testing -> Imdet=14   20
             deltam*x[varind[14,n]], # outflow: confirmed mild cases (seek+test) Imdet=14 ->  21
             pdets*taus*x[varind[6,n]], # inflow:  severe/critical cases for testing upon entry to hosp -> Isdet=15  22
             deltas*x[varind[15,n]] # outflow: confirmed severe cases  (test) Isdet=15 ->   23

           )
         }
         return(c(t(tranrate)))
       })
}

# POST PROCESSING function
postproc <- function(parpro,out,tran) {
  with(as.list(c( parpro)),
       {
         # ************************************************************************************* #
         # for outputting the  time series for each patch
         # ************************************************************************************* #
         
         # Case outputs
         deathgen_pred<-deathicu_pred<-admicu_pred<-admit_pred<-inc_pred<-asym_pred<-hosp_beds<-icu_beds<-mdet_pred<-sdet_pred<-prev_pred<-mild_pred<-sev_pred<-crit_pred<-death_pred<-matrix(0,nrow=length(out[,1]),ncol=N)
         for (n in 1:N){
           mild_pred[,n]<-tran[,c(traind[7,n])]/365 + tran[,c(traind[1,n])] #count mild incidence + mild importations
           sev_pred[,n]<-(tran[,c(traind[8,n])])/365 + tran[,c(traind[2,n])] #count severe incidence + severe importations
           crit_pred[,n]<-(tran[,c(traind[10,n])])/365 + tran[,c(traind[3,n])]#
           asym_pred[,n]<-(tran[,c(traind[5,n])])/365 
           death_pred[,n]<-(tran[,c(traind[16,n])]+tran[,c(traind[17,n])])/365
           hosp_beds[,n]<-rowSums(out[,c(varind[c(7,8,11),n])+1])
           icu_beds[,n]<-rowSums(out[,c(varind[c(9,10),n])+1])
           prev_pred[,n]<-rowSums(out[,c(varind[c(2:11),n])+1])
           mdet_pred[,n]<-(tran[,c(traind[21,n])])/365 + tran[,c(traind[1,n])] #local mild detections + mild imported (not counted in rate)
           sdet_pred[,n]<-(tran[,c(traind[23,n])])/365 + tran[,c(traind[2,n])] +tran[,c(traind[3,n])]  #local severe detections + severe imported (not counted in rate)
           inc_pred[,n]<-(tran[,c(traind[4,n])])/365 
           admit_pred[,n]<-(tran[,c(traind[9,n])])/365
           admicu_pred[,n]<-(tran[,c(traind[11,n])])/365+(tran[,c(traind[12,n])])/365
           deathgen_pred[,n]<-(tran[,c(traind[16,n])])/365
           deathicu_pred[,n]<-(tran[,c(traind[17,n])])/365
           
        }
         
         
         return(cbind(mild_pred,    #1
                      sev_pred,     #2
                      crit_pred,  #3
                      asym_pred, #4
                      death_pred,  #5
                      prev_pred, #6
                      hosp_beds, #7
                      icu_beds,  #8
                      mdet_pred, #9
                      sdet_pred,  #10
                      inc_pred, #11
                      admit_pred, #12
                      admicu_pred, #13
                      deathgen_pred, #14
                      deathicu_pred #15

         ))
         
       })
}

ti<-1

# ************************************************************************************* #
# ************************************************************************************* #
# ************************************************************************************* #
# ODE SOLVER
# ************************************************************************************* #
# ************************************************************************************* #

epiModel<-function(t,state, parode,input, scenario) 
{ 
  
  with(as.list(c(state, parode)),
       {
         
         #   # ************************************************************************************* #
         #   # define variables
         #   # ************************************************************************************* #
         
         Z=state
         
         # rates of change
         ti<-1
         transit<-covrates(Z[1:V],input,parode,Z[V+1],ti, scenario)  
         
         if (sum(is.na(transit))>0)  {
           stop("transit NA   ",Z[V+1], "                                      ", 
                as.data.frame(transit))
         }
         
         transit2<-transit
         
         eq<-rep(0.0, V)
         
         eq<-EQ(L, N, eq, transit2,transitionsiu1,transitionsiu2,transitionsiv1,transitionsiv2)
         
         eq[V+1]<-1
         
         dZ<-eq
         
         # return the rate of change
         list(c(dZ))
       }
  ) 
  # end with(as.list ...
}

#*************************************************************************
#*************************************************************************

# MODEL RUN FUNCTION
# Run function
run <- function(parrun, scenario){
  
  # ************************************************************************************* #
  # define initial conditions
  initcondrun<-NULL
  for (n in 1:N) { initcondrun<-c(initcondrun, c(pvxy[n,2],rep(0,14))); 
                   initcondrun[varind[5,n]]<-parrun$pm[n]*seedfac[n]*as.numeric((casesp[23,n+1]-casesp[18,n+1]));
                   initcondrun[varind[6,n]]<-(1-parrun$pm[n])*seedfac[n]*as.numeric((casesp[23,n+1]-casesp[18,n+1])) 
                   } 
  
  # all initial conditions must be integers
  initoderun<-initcondrun
  staterun <- c(initoderun,0)
  ti<-1
  inp<-inputs(parrun)
  transitrun <- covrates(initoderun,inp,parrun,0,ti,scenario )
  
  #
  # # SOLVE THE ODEs and get output
  timesrun <- seq(0, tyears, by = dtout) # Model run time
  #Solve ODE
  outoderun <- ode(y = staterun, times = timesrun, func = epiModel, parms = parrun, method  = "vode", input=inp,scenario=scenario )
  # Compute transitions at each time step
  tranoderun<-matrix(0,nrow=length(outoderun[,1]),ncol=length(transitions))
  for (ti in 1:(tsteps+1)){
    tranoderun[ti,]<-t(covrates(outoderun[ti,2:(1+V)],inp,parrun,0,ti,scenario ))
  }
  #Compute outputs
  ppout<-postproc(parrun,outoderun,tranoderun)
  modeltimes<-outoderun[,1]+startyear
  
  mild_pred_ode<-ppout[,1:N]
  sev_pred_ode<-ppout[,(N+1):(2*N)]
  crit_pred_ode<-ppout[,(2*N+1):(3*N)]
  asym_pred_ode<-ppout[,(3*N+1):(4*N)]
  death_pred_ode<-ppout[,(4*N+1):(5*N)]
  prev_pred_ode<-ppout[,(5*N+1):(6*N)]
  hosp_beds_ode<-ppout[,(6*N+1):(7*N)]
  icu_beds_ode<-ppout[,(7*N+1):(8*N)]
  mdet_pred_ode<-ppout[,(8*N+1):(9*N)]
  sdet_pred_ode<-ppout[,(9*N+1):(10*N)]
  totinc_pred_ode<-ppout[,(10*N+1):(11*N)]
  admit_pred_ode<-ppout[,(11*N+1):(12*N)]
  admicu_pred_ode<-ppout[,(12*N+1):(13*N)]
  deathgen_pred_ode<-ppout[,(13*N+1):(14*N)]
  deathicu_pred_ode<-ppout[,(14*N+1):(15*N)]
  
  inc_pred_ode<-mild_pred_ode+sev_pred_ode
  
 
  
  COVout<-list(modeltimes, #1
               mild_pred_ode,#2
               sev_pred_ode,#3
               crit_pred_ode,#4
               asym_pred_ode,#5
               death_pred_ode,#6
               prev_pred_ode,#7
               hosp_beds_ode,#8
               icu_beds_ode,#9
               mdet_pred_ode,#10
               sdet_pred_ode,#11
               inc_pred_ode,#12
               totinc_pred_ode,#13
               outoderun, #14
               tranoderun, #15
               admit_pred_ode, #16
               admicu_pred_ode, #17
               deathgen_pred_ode, #18
               deathicu_pred_ode #19
               
  )
  
 
  
  
  return(COVout)
}

dtimes<-format(as.Date(time*365,origin="2020-03-01"), "%d/%m/%Y")
dweeks<-dtimes[seq(1,length(dtimes),7)]
dtimes2<-as.Date(time*365,origin="2020-03-01")

#############################################
#Scenario definition
#############################################

scenario<-matrix(0, 3, 3)
scenario[1,]<-c(0, 0, 0)  #no intervention
scenario[2,]<-c(0, 1, 0)  #i2 Optimistic  
scenario[3,]<-c(0, 0, 1)  #i3 Pessimistic
scenario<-cbind(i1=scenario[,1],i2=scenario[,2],i3=scenario[,3] )


#############################################

#Single run
seedfac<-rep(10,N) #seed inflation factor
inf<-rep(4, N)  #detection factor  
pars$pdetm<-1/inf # apply detection factor to detection of mild cases 
pars$pdets<-1 # all hospitalised cases assumed to be detected
pars$beta0<-pars$R0/pars$durinf
scen<-2 #Specify the scenario to run
st<-Sys.time()
out<-run(pars, scenario[scen,])
en<-Sys.time()
en-st

cum_deathgen<-cum_deathicu<-cum_admgen<-cum_admicu<-cum_totinc<-cum_inc<-cum_det<-matrix(0, dim(out[[2]])[1],dim(out[[2]])[2] )
for (n in 1:N){
   cum_inc[,n]<-cumsum(out[[12]][,n])
   cum_totinc[,n]<-cumsum(out[[13]][,n])
   cum_det[,n]<-cumsum(out[[10]][,n]+out[[11]][,n])
   cum_admgen[,n]<-cumsum(out[[16]][,n])
   cum_admicu[,n]<-cumsum(out[[17]][,n])
   cum_deathgen[,n]<-cumsum(out[[18]][,n])
   cum_deathicu[,n]<-cumsum(out[[19]][,n])
}
t<-c(73,103, 134,165,195, 226  ) #Monthly from 1 June 2020
nat<-cbind(Date=dtimes[t],Cum_IncT=rowSums(cum_totinc[t,]), Cum_SymInc=rowSums(cum_inc[t,]),Detected=rowSums(cum_det[t,]), HospBeds=rowSums(out[[8]][t,]),ICUbeds=rowSums(out[[9]][t,]), Cum_Deaths=rowSums(out[[14]][t,varind[c(13),]+1]),ActiveMild = rowSums(out[[14]][t,varind[c(5),]+1]), ActiveSevere = rowSums(out[[14]][t,varind[c(6,7),]+1]), ActiveCrit = rowSums(out[[14]][t,varind[c(8:11),]+1]),ActiveAsymp = rowSums(out[[14]][t,varind[c(3, 4),]+1]), ActiveSym = rowSums(out[[14]][t,varind[c(5:11),]+1]), ActiveAll=rowSums(out[[14]][t,varind[c(3:11),]+1]), AdmHosp=rowSums(cum_admgen[t,]), AdmICU=rowSums(cum_admicu[t,]))
nat
prov<-NULL
for (n in 1:N) {
  provp<-cbind(Date=dtimes[t],Cum_IncT=(cum_totinc[t,n]), Cum_SymInc=(cum_inc[t,n]),Detected=(cum_det[t,n]), HospBeds=(out[[8]][t,n]),ICUbeds=(out[[9]][t,n]), Cum_Deaths=(out[[14]][t,varind[c(13),n]+1]),ActiveMild=(out[[14]][t,varind[c(5),n]+1]), ActiveSevere=rowSums(out[[14]][t,varind[c(6,7),n]+1]), ActiveCrit=rowSums(out[[14]][t,varind[c(8:11),n]+1]), ActiveAsymp=rowSums(out[[14]][t,varind[c(3, 4),n]+1]), ActiveSym=rowSums(out[[14]][t,varind[c(5:11),n]+1]), ActiveAll=rowSums(out[[14]][t,varind[c(3:11),n]+1]), AdmHosp=(cum_admgen[t,n]), AdmICU=(cum_admicu[t,n]))
  prov<-c(prov, list(provp))
  }
prov




#Comparison of Scenarios (No Intervention, 5wk Lockdown)
####################################
pars$beta0<-pars$R0/pars$durinf
pars$r4<-365/14
outo_0<-run(pars, scenario[1,])
pars$r4<-365/18
outp_0<-run(pars, scenario[1,])
outo_5<-run(pars, scenario[2,])
outp_5<-run(pars, scenario[3,])

t<-1:(250-sday)
dtimes2<-as.Date(time*365,origin="2020-03-01")
par(mfrow=c(1,1))
plot(dtimes2[t],rowSums(outo_0[[7]][t,]), ty="l", xaxt="n",lwd=3,ylim=c(0,max(rowSums(outp_0[[7]][t,]))), xlab="", ylab="")
lines(dtimes2[t],rowSums(outp_0[[7]][t,]), col=1, lty=2, lwd=3)
lines(dtimes2[t],rowSums(outo_5[[7]][t,]), col="green4",lwd=3, lty=1)
lines(dtimes2[t],rowSums(outp_5[[7]][t,]), col="green4",lwd=3, lty=2)
axis.Date(1, at = seq(dtimes2[1], dtimes2[length(t)], 4),format = "%d-%m", las = 2)
mtext("Prevalence - No lockdown (black), 5wk lockdown (green), Optimistic (solid), Pessimistic (dashed)", side=3, line=2, cex=1)







###########################
#Run mulitple times (stochastic parameters)
###########################
registerDoParallel(numCores) #register cores
it<-n_iterations
set.seed(108) #set seed 
#Note that setting the seed will not guarantee replication of results when running in parallel

st<-Sys.time()
sderunO<-foreach(r=1:it) %dopar% {
  parsim = {list(
    gamma1 = rtri(1, parameters$Lower[1], parameters$Upper[1], parameters$Value[1] ),  #1/non-infectious incubation duration
    gamma2 = rtri(1, parameters$Lower[2], parameters$Upper[2], parameters$Value[2]),  #1/infectious incubation duration
    r1=rtri(1, parameters$Lower[3], parameters$Upper[3], parameters$Value[3]), # 1/dur infectiousness (asymp)
    r2=rtri(1, parameters$Lower[4], parameters$Upper[4], parameters$Value[4]), # 1/dur infectiousness (mild)
    mu = rtri(1, parameters$Lower[5], parameters$Upper[5], parameters$Value[5]), #death rate
    beta0 = rep(parameters$Value[6],N), # no. of effective contacts #defined below
    R0 = rtri(1, parameters$Lower[7], parameters$Upper[7], parameters$Value[7]), # basic reproductive number
    taus=rtri(1, parameters$Lower[8], parameters$Upper[8], parameters$Value[8]), # 1/trt seeking severe
    pa = rtri(1, parameters$Lower[9], parameters$Upper[9], parameters$Value[9]), # asymptomatic proportion of infections
    tauprog = rtri(1, parameters$Lower[10], parameters$Upper[10], parameters$Value[10]), # 1/ duration of progression of severe cases to critical
    zeta1 = rtri(1, parameters$Lower[11], parameters$Upper[11], parameters$Value[11]), #relative infectiousness of asymptomatic population
    r3=rtri(1, parameters$Lower[12], parameters$Upper[12], parameters$Value[12]), #1/dur stay hospital (severe)
    r4=rtri(1, parameters$Lower[13], parameters$Upper[13], parameters$Value[13]), #1/dur stay ICU (critical)
    pdetm=parameters$Value[14],#detection rate mild defined below
    pdets= parameters$Value[15],#detection rate severe/critical #defined below
    deltam = rtri(1, parameters$Lower[16], parameters$Upper[16], parameters$Value[16]), #lead time confirmation mild 
    deltas = rtri(1, parameters$Lower[17], parameters$Upper[17], parameters$Value[17]), #lead time confirmation severe/critical 
    r5=rtri(1, parameters$Lower[18], parameters$Upper[18], parameters$Value[18]) #1/dur stay hospital (postcritical)
    
    );
  }
  parsim$ps<-rtri(1,0.8,1.2, 1)*as.numeric(sev[2,2:10])
  parsim$pc<-rtri(1,0.8,1.2, 1)*as.numeric(sev[3,2:10])
  parsim$pm<-1-parsim$ps-parsim$pc 
  
  parsim$pd1<-rep(0, N)
  parsim$pd2<-rtri(1,0.8,1.2, 1)*as.numeric(sev[4,2:10])
  parsim$durinf<-(parsim$zeta1*parsim$pa/parsim$r1 + (1-parsim$pa)/parsim$gamma2 + (1-parsim$pa)*pars$pm/parsim$r2 + (1-parsim$pa)*(1-parsim$pm)/parsim$taus) #compute duration of infection accounting for all levels of severity (annual units)
  
  
    seedfac<-rep(10,N) #seed inflation factor 
    inf<-rep(4, N)
    parsim$pdetm<-1/inf # apply inflation factor to detection of mild cases 
    parsim$pdets<-1 # 
    parsim$beta0<-rep(parsim$R0/parsim$durinf)
          
   outode<-run(parsim, scenario[2,]) #Run solver
  return(outode)
  
}  #scenario 2: Optimistic
sderunP<-foreach(r=1:it) %dopar% {
  parsim = {list(
    gamma1 = rtri(1, parameters$Lower[1], parameters$Upper[1], parameters$Value[1] ),  #1/non-infectious incubation duration
    gamma2 = rtri(1, parameters$Lower[2], parameters$Upper[2], parameters$Value[2]),  #1/infectious incubation duration
    r1=rtri(1, parameters$Lower[3], parameters$Upper[3], parameters$Value[3]), # 1/dur infectiousness (asymp)
    r2=rtri(1, parameters$Lower[4], parameters$Upper[4], parameters$Value[4]), # 1/dur infectiousness (mild)
    mu = rtri(1, parameters$Lower[5], parameters$Upper[5], parameters$Value[5]), #death rate
    beta0 = rep(parameters$Value[6],N), # no. of effective contacts #defined below
    R0 = rtri(1, parameters$Lower[7], parameters$Upper[7], parameters$Value[7]), # basic reproductive number
    taus=rtri(1, parameters$Lower[8], parameters$Upper[8], parameters$Value[8]), # 1/trt seeking severe
    pa = rtri(1, parameters$Lower[9], parameters$Upper[9], parameters$Value[9]), # asymptomatic proportion of infections
    tauprog = rtri(1, parameters$Lower[10], parameters$Upper[10], parameters$Value[10]), # 1/ duration of progression of severe cases to critical
    zeta1 = rtri(1, parameters$Lower[11], parameters$Upper[11], parameters$Value[11]), #relative infectiousness of asymptomatic population
    r3=rtri(1, parameters$Lower[12], parameters$Upper[12], parameters$Value[12]), #1/dur stay hospital (severe)
    r4=rtri(1, parameters$Lower[13], parameters$Upper[13], parameters$Value[13]), #1/dur stay ICU (critical)
    pdetm=parameters$Value[14],#detection rate mild defined below
    pdets= parameters$Value[15],#detection rate severe/critical #defined below
    deltam = rtri(1, parameters$Lower[16], parameters$Upper[16], parameters$Value[16]), #lead time confirmation mild 
    deltas = rtri(1, parameters$Lower[17], parameters$Upper[17], parameters$Value[17]), #lead time confirmation severe/critical 
    r5=rtri(1, parameters$Lower[18], parameters$Upper[18], parameters$Value[18]) #1/dur stay hospital (postcritical)
    
  );
  }
  parsim$ps<-rtri(1,0.8,1.2, 1)*as.numeric(sev[2,2:10])
  parsim$pc<-rtri(1,0.8,1.2, 1)*as.numeric(sev[3,2:10])
  parsim$pm<-1-parsim$ps-parsim$pc 
  
  parsim$pd1<-rep(0, N)
  parsim$pd2<-rtri(1,0.8,1.2, 1)*as.numeric(sev[4,2:10])
  parsim$durinf<-(parsim$zeta1*parsim$pa/parsim$r1 + (1-parsim$pa)/parsim$gamma2 + (1-parsim$pa)*pars$pm/parsim$r2 + (1-parsim$pa)*(1-parsim$pm)/parsim$taus) #compute duration of infection accounting for all levels of severity (annual units)
  
  
  seedfac<-rep(10,N) #seed inflation factor 
  inf<-rep(4, N)
  parsim$pdetm<-1/inf # apply inflation factor to detection of mild cases 
  parsim$pdets<-1 # 
  parsim$beta0<-rep(parsim$R0/parsim$durinf)
  
  outode<-run(parsim, scenario[3,]) #Run solver
  return(outode)
  
}  #scenario 3: Pessimistic

save(sderunO, file="runO_it_date")
save(sderunP, file="runP_it_date")

et<-Sys.time()
et-st
length(sderunO);length(sderunP)     

###########################

#Prepare outputs
###########################
# 
runs<-it
#Process Optimistic Runs
sderun<-sderunO
{
Sus<-MildInc<-IncT<-Inc<-Det<-Hosp<-ICU<-Death<-Amild<-Asev<-Acrit<-Aasym<-Asym<-Aall<-AdmHosp<-AdmICU<-array(0, c(runs,length(rowSums(sderun[[1]][[7]])),N))
SusN<-MildIncN<-IncTN<-IncN<-DetN<-HospN<-ICUN<-DeathN<-AmildN<-AsevN<-AcritN<-AasymN<-AsymN<-AallN<-AdmHospN<-AdmICUN<-array(0,c(runs,length(rowSums(sderun[[1]][[7]]))))
for (i in 1:runs){
  IncTN[i,]<-rowSums(sderun[[i]][[13]])
  IncN[i,]<-rowSums(sderun[[i]][[12]])
  MildIncN[i,]<-rowSums(sderun[[i]][[2]])
  DetN[i,]<-rowSums(sderun[[i]][[10]])+rowSums(sderun[[i]][[11]])
  HospN[i,]<-rowSums(sderun[[i]][[8]])
  ICUN[i,]<-rowSums(sderun[[i]][[9]])
  DeathN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(13),]+1])
  AmildN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(5),]+1])
  AsevN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(6,7),]+1])
  AcritN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(8:11),]+1])
  AasymN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(3,4),]+1])
  AsymN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(5:11),]+1])
  AallN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(3:11),]+1])
  SusN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(1),]+1])
  AdmHospN[i,]<-rowSums(sderun[[i]][[16]])
  AdmICUN[i,]<-rowSums(sderun[[i]][[17]])

  
  IncT[i,,]<-(sderun[[i]][[13]])
  Inc[i,,]<-(sderun[[i]][[12]])
  MildInc[i,,]<-(sderun[[i]][[2]])
  Det[i,,]<-(sderun[[i]][[10]])+(sderun[[i]][[11]])
  Hosp[i,,]<-(sderun[[i]][[8]])
  ICU[i,,]<-(sderun[[i]][[9]])
  Death[i,,]<-(sderun[[i]][[14]][,varind[c(13),]+1])
  Amild[i,,]<-(sderun[[i]][[14]][,varind[c(5),]+1])
  Sus[i,,]<-(sderun[[i]][[14]][,varind[c(1),]+1])
  AdmHosp[i,,]<-(sderun[[i]][[16]])
  AdmICU[i,,]<-(sderun[[i]][[17]])

  
  for (n in 1:N){
  Asev[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(6,7),n]+1])
  Acrit[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(8:11),n]+1])
  Asym[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(5:11),n]+1])
  Aasym[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(3,4),n]+1])
  Aall[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(3:11),n]+1])}
   }
CIncTN<-t(apply(t(IncTN), 2, cumsum))
CIncN<-t(apply(t(IncN), 2, cumsum))
CDetN<-t(apply(t(DetN), 2, cumsum))
CMildIncN<-t(apply(t(MildIncN), 2, cumsum))
CAdmHospN<-t(apply(t(AdmHospN), 2, cumsum))
CAdmICUN<-t(apply(t(AdmICUN), 2, cumsum))

CIncT<-IncT
CInc<-Inc
CDet<-Det
CMildInc<-MildInc
CAdmHosp<-AdmHosp
CAdmICU<-AdmICU


for (i in 1:runs){ for (j in 1:N){
  CIncT[i,,j]<-cumsum(IncT[i,,j])
  CInc[i,,j]<-cumsum(Inc[i,,j])
  CDet[i,,j]<-cumsum(Det[i,,j])
  CMildInc[i,,j]<-cumsum(MildInc[i,,j])
  CAdmHosp[i,,j]<-cumsum(AdmHosp[i,,j])
  CAdmICU[i,,j]<-cumsum(AdmICU[i,,j])

  
}}

CMildIncq<-CIncTq<-CIncq<-CDetq<-CAdmHospq<-CAdmICUq<-IncTq<-Incq<-Hospq<-ICUq<-Deathq<-Amildq<-Asevq<-Acritq<-Aasymq<-Asymq<-Aallq<-Susq<-AdmHospq<-AdmICUq<-array(0, c(length(rowSums(sderun[[1]][[7]])),5,N))
CMildIncNq<-CIncTNq<-CIncNq<-CDetNq<-CAdmHospNq<-CAdmICUNq<-IncTNq<-IncNq<-HospNq<-ICUNq<-DeathNq<-AmildNq<-AsevNq<-AcritNq<-AasymNq<-AsymNq<-AallNq<-SusNq<-AdmHospNq<-AdmICUNq<-array(0, c(length(rowSums(sderun[[1]][[7]])),5))
for (i in 1:length(rowSums(sderun[[1]][[7]]))){
  CIncTNq[i,]<-quantile(CIncTN[,i], probs = c(5, 25, 50, 75, 95)/100)
  CIncNq[i,]<-quantile(CIncN[,i], probs = c(5, 25, 50, 75, 95)/100)
  CMildIncNq[i,]<-quantile(CMildIncN[,i], probs = c(5, 25, 50, 75, 95)/100)
  CDetNq[i,]<-quantile(CDetN[,i], probs = c(5, 25, 50, 75, 95)/100)
  CAdmHospNq[i,]<-quantile(CAdmHospN[,i], probs = c(5, 25, 50, 75, 95)/100)
  CAdmICUNq[i,]<-quantile(CAdmICUN[,i], probs = c(5, 25, 50, 75, 95)/100)
  IncTNq[i,]<-quantile(IncTN[,i], probs = c(5, 25, 50, 75, 95)/100)
  IncNq[i,]<-quantile(IncN[,i], probs = c(5, 25, 50, 75, 95)/100)
  HospNq[i,]<-quantile(HospN[,i], probs = c(5, 25, 50, 75, 95)/100)
  ICUNq[i,]<-quantile(ICUN[,i], probs = c(5, 25, 50, 75, 95)/100)
  DeathNq[i,]<-quantile(DeathN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AmildNq[i,]<-quantile(AmildN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AsevNq[i,]<-quantile(AsevN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AcritNq[i,]<-quantile(AcritN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AasymNq[i,]<-quantile(AasymN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AsymNq[i,]<-quantile(AsymN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AallNq[i,]<-quantile(AallN[,i], probs = c(5, 25, 50, 75, 95)/100)
  SusNq[i,]<-quantile(SusN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AdmHospNq[i,]<-quantile(AdmHospN[,i], probs = c(5, 25, 50, 75, 95)/100)
  AdmICUNq[i,]<-quantile(AdmICUN[,i], probs = c(5, 25, 50, 75, 95)/100)
  
  for (j in 1:N){
    CIncTq[i,,j]<-quantile(CIncT[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    CIncq[i,,j]<-quantile(CInc[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    CMildIncq[i,,j]<-quantile(CMildInc[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    CDetq[i,,j]<-quantile(CDet[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    CAdmHospq[i,,j]<-quantile(CAdmHosp[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    CAdmICUq[i,,j]<-quantile(CAdmICU[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    IncTq[i,,j]<-quantile(IncT[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Incq[i,,j]<-quantile(Inc[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Hospq[i,,j]<-quantile(Hosp[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    ICUq[i,,j]<-quantile(ICU[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Deathq[i,,j]<-quantile(Death[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Amildq[i,,j]<-quantile(Amild[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Asevq[i,,j]<-quantile(Asev[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Acritq[i,,j]<-quantile(Acrit[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Aasymq[i,,j]<-quantile(Aasym[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Asymq[i,,j]<-quantile(Asym[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Aallq[i,,j]<-quantile(Aall[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    Susq[i,,j]<-quantile(Sus[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    AdmHospq[i,,j]<-quantile(AdmHosp[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    AdmICUq[i,,j]<-quantile(AdmICU[,i,j], probs = c(5, 25, 50, 75, 95)/100)
  }
}


#Export
t<-2:255
NatOptq<-list(Date=dtimes[t],CumIncT=CIncTNq[t,],SympInc=CIncNq[t,], MildInc=CMildIncNq[t,], Detected=CDetNq[t,],HospBeds=HospNq[t,],ICUBeds=ICUNq[t,],AdmGen=AdmHospNq[t,],AdmICU=AdmICUNq[t,], CDeaths=DeathNq[t,],ActMild=AmildNq[t,],ActSev=AsevNq[t,],ActCrit=AcritNq[t,],ActAsym=AasymNq[t,],ActSym=AsymNq[t,],ActAll=AallNq[t,], Sus=SusNq[t,])
write.xlsx(NatOptq, file="NatOptLong.xlsx")
optprov<-list()
for (n in 1:N){optprov[[n]]<-list(Date=dtimes,CumIncT=CIncTq[t,,n],SympInc=CIncq[t,,n], MildInc=CMildIncq[t,,n],Detected=CDetq[t,,n],HospBeds=Hospq[t,,n],ICUBeds=ICUq[t,,n],CAdmGen=CAdmHospq[t,,n],CAdmICU=CAdmICUq[t,,n],CDeaths=Deathq[t,,n], ActMild=Amildq[t,,n],ActSev=Asevq[t,,n],ActCrit=Acritq[t,,n],ActAsym=Aasymq[t,,n],ActSym=Asymq[t,,n],ActAll=Aallq[t,,n], Sus=Susq[t,,n])}
names(optprov)<-pvxy[,1]

for (n in 1:N){                      
write.xlsx(optprov[[n]], file=paste(names(optprov)[[n]],"optprovLong.xlsx"))
}
}

#Process Pessimistic Runs
sderun<-sderunP
{
  Sus<-MildInc<-IncT<-Inc<-Det<-Hosp<-ICU<-Death<-Amild<-Asev<-Acrit<-Aasym<-Asym<-Aall<-AdmHosp<-AdmICU<-array(0, c(runs,length(rowSums(sderun[[1]][[7]])),N))
  SusN<-MildIncN<-IncTN<-IncN<-DetN<-HospN<-ICUN<-DeathN<-AmildN<-AsevN<-AcritN<-AasymN<-AsymN<-AallN<-AdmHospN<-AdmICUN<-array(0,c(runs,length(rowSums(sderun[[1]][[7]]))))
  for (i in 1:runs){
    IncTN[i,]<-rowSums(sderun[[i]][[13]])
    IncN[i,]<-rowSums(sderun[[i]][[12]])
    MildIncN[i,]<-rowSums(sderun[[i]][[2]])
    DetN[i,]<-rowSums(sderun[[i]][[10]])+rowSums(sderun[[i]][[11]])
    HospN[i,]<-rowSums(sderun[[i]][[8]])
    ICUN[i,]<-rowSums(sderun[[i]][[9]])
    DeathN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(13),]+1])
    AmildN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(5),]+1])
    AsevN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(6,7),]+1])
    AcritN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(8:11),]+1])
    AasymN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(3,4),]+1])
    AsymN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(5:11),]+1])
    AallN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(3:11),]+1])
    SusN[i,]<-rowSums(sderun[[i]][[14]][,varind[c(1),]+1])
    AdmHospN[i,]<-rowSums(sderun[[i]][[16]])
    AdmICUN[i,]<-rowSums(sderun[[i]][[17]])
    
    
    IncT[i,,]<-(sderun[[i]][[13]])
    Inc[i,,]<-(sderun[[i]][[12]])
    MildInc[i,,]<-(sderun[[i]][[2]])
    Det[i,,]<-(sderun[[i]][[10]])+(sderun[[i]][[11]])
    Hosp[i,,]<-(sderun[[i]][[8]])
    ICU[i,,]<-(sderun[[i]][[9]])
    Death[i,,]<-(sderun[[i]][[14]][,varind[c(13),]+1])
    Amild[i,,]<-(sderun[[i]][[14]][,varind[c(5),]+1])
    Sus[i,,]<-(sderun[[i]][[14]][,varind[c(1),]+1])
    AdmHosp[i,,]<-(sderun[[i]][[16]])
    AdmICU[i,,]<-(sderun[[i]][[17]])
    
    
    for (n in 1:N){
      Asev[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(6,7),n]+1])
      Acrit[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(8:11),n]+1])
      Asym[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(5:11),n]+1])
      Aasym[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(3,4),n]+1])
      Aall[i,,n]<-rowSums(sderun[[i]][[14]][,varind[c(3:11),n]+1])}
  }
  CIncTN<-t(apply(t(IncTN), 2, cumsum))
  CIncN<-t(apply(t(IncN), 2, cumsum))
  CDetN<-t(apply(t(DetN), 2, cumsum))
  CMildIncN<-t(apply(t(MildIncN), 2, cumsum))
  CAdmHospN<-t(apply(t(AdmHospN), 2, cumsum))
  CAdmICUN<-t(apply(t(AdmICUN), 2, cumsum))
  
  CIncT<-IncT
  CInc<-Inc
  CDet<-Det
  CMildInc<-MildInc
  CAdmHosp<-AdmHosp
  CAdmICU<-AdmICU
  
  
  for (i in 1:runs){ for (j in 1:N){
    CIncT[i,,j]<-cumsum(IncT[i,,j])
    CInc[i,,j]<-cumsum(Inc[i,,j])
    CDet[i,,j]<-cumsum(Det[i,,j])
    CMildInc[i,,j]<-cumsum(MildInc[i,,j])
    CAdmHosp[i,,j]<-cumsum(AdmHosp[i,,j])
    CAdmICU[i,,j]<-cumsum(AdmICU[i,,j])
    
    
  }}
  
  CMildIncq<-CIncTq<-CIncq<-CDetq<-CAdmHospq<-CAdmICUq<-IncTq<-Incq<-Hospq<-ICUq<-Deathq<-Amildq<-Asevq<-Acritq<-Aasymq<-Asymq<-Aallq<-Susq<-AdmHospq<-AdmICUq<-array(0, c(length(rowSums(sderun[[1]][[7]])),5,N))
  CMildIncNq<-CIncTNq<-CIncNq<-CDetNq<-CAdmHospNq<-CAdmICUNq<-IncTNq<-IncNq<-HospNq<-ICUNq<-DeathNq<-AmildNq<-AsevNq<-AcritNq<-AasymNq<-AsymNq<-AallNq<-SusNq<-AdmHospNq<-AdmICUNq<-array(0, c(length(rowSums(sderun[[1]][[7]])),5))
  for (i in 1:length(rowSums(sderun[[1]][[7]]))){
    CIncTNq[i,]<-quantile(CIncTN[,i], probs = c(5, 25, 50, 75, 95)/100)
    CIncNq[i,]<-quantile(CIncN[,i], probs = c(5, 25, 50, 75, 95)/100)
    CMildIncNq[i,]<-quantile(CMildIncN[,i], probs = c(5, 25, 50, 75, 95)/100)
    CDetNq[i,]<-quantile(CDetN[,i], probs = c(5, 25, 50, 75, 95)/100)
    CAdmHospNq[i,]<-quantile(CAdmHospN[,i], probs = c(5, 25, 50, 75, 95)/100)
    CAdmICUNq[i,]<-quantile(CAdmICUN[,i], probs = c(5, 25, 50, 75, 95)/100)
    IncTNq[i,]<-quantile(IncTN[,i], probs = c(5, 25, 50, 75, 95)/100)
    IncNq[i,]<-quantile(IncN[,i], probs = c(5, 25, 50, 75, 95)/100)
    HospNq[i,]<-quantile(HospN[,i], probs = c(5, 25, 50, 75, 95)/100)
    ICUNq[i,]<-quantile(ICUN[,i], probs = c(5, 25, 50, 75, 95)/100)
    DeathNq[i,]<-quantile(DeathN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AmildNq[i,]<-quantile(AmildN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AsevNq[i,]<-quantile(AsevN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AcritNq[i,]<-quantile(AcritN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AasymNq[i,]<-quantile(AasymN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AsymNq[i,]<-quantile(AsymN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AallNq[i,]<-quantile(AallN[,i], probs = c(5, 25, 50, 75, 95)/100)
    SusNq[i,]<-quantile(SusN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AdmHospNq[i,]<-quantile(AdmHospN[,i], probs = c(5, 25, 50, 75, 95)/100)
    AdmICUNq[i,]<-quantile(AdmICUN[,i], probs = c(5, 25, 50, 75, 95)/100)
    
    for (j in 1:N){
      CIncTq[i,,j]<-quantile(CIncT[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      CIncq[i,,j]<-quantile(CInc[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      CMildIncq[i,,j]<-quantile(CMildInc[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      CDetq[i,,j]<-quantile(CDet[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      CAdmHospq[i,,j]<-quantile(CAdmHosp[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      CAdmICUq[i,,j]<-quantile(CAdmICU[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      IncTq[i,,j]<-quantile(IncT[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Incq[i,,j]<-quantile(Inc[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Hospq[i,,j]<-quantile(Hosp[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      ICUq[i,,j]<-quantile(ICU[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Deathq[i,,j]<-quantile(Death[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Amildq[i,,j]<-quantile(Amild[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Asevq[i,,j]<-quantile(Asev[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Acritq[i,,j]<-quantile(Acrit[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Aasymq[i,,j]<-quantile(Aasym[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Asymq[i,,j]<-quantile(Asym[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Aallq[i,,j]<-quantile(Aall[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      Susq[i,,j]<-quantile(Sus[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      AdmHospq[i,,j]<-quantile(AdmHosp[,i,j], probs = c(5, 25, 50, 75, 95)/100)
      AdmICUq[i,,j]<-quantile(AdmICU[,i,j], probs = c(5, 25, 50, 75, 95)/100)
    }
  }
  
  
  #Export
  t<-2:255
  NatPesq<-list(Date=dtimes[t],CumIncT=CIncTNq[t,],SympInc=CIncNq[t,],MildInc=CMildIncNq[t,],Detected=CDetNq[t,],HospBeds=HospNq[t,],ICUBeds=ICUNq[t,],AdmGen=AdmHospNq[t,],AdmICU=AdmICUNq[t,],CDeaths=DeathNq[t,],ActMild=AmildNq[t,],ActSev=AsevNq[t,],ActCrit=AcritNq[t,],ActAsym=AasymNq[t,],ActSym=AsymNq[t,],ActAll=AallNq[t,], Sus=SusNq[t,])
  write.xlsx(NatPesq, file="NatPesLong.xlsx")
  
  
  pesprov<-list()
  for (n in 1:N){pesprov[[n]]<-list(Date=dtimes,CumIncT=CIncTq[t,,n],SympInc=CIncq[t,,n],MildInc=CMildIncq[t,,n], Detected=CDetq[t,,n],HospBeds=Hospq[t,,n],ICUBeds=ICUq[t,,n],CAdmGen=CAdmHospq[t,,n],CAdmICU=CAdmICUq[t,,n],CDeaths=Deathq[t,,n],ActMild=Amildq[t,,n],ActSev=Asevq[t,,n],ActCrit=Acritq[t,,n],ActAsym=Aasymq[t,,n],ActSym=Asymq[t,,n],ActAll=Aallq[t,,n], Sus=Susq[t,,n])}
  names(pesprov)<-pvxy[,1]
  
  for (n in 1:N){                      
    write.xlsx(pesprov[[n]], file=paste(names(pesprov)[[n]],"pesprovLong.xlsx"))
  }
}

source('./plots.R')

