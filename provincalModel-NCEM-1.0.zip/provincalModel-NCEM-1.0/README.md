# National COVID-19 Epi Model - Code for provincal model

The code in this repository runs the province-level model used to generate results for the national and provincial long-term reports released on 19 May. 
Information on the structure and logic of the code are summarized in the [NCEM Provincial Model Code Guide](http://sacovid19mc.github.io/ncemProvincialCodeGuide.pdf). Additional information on the model equations, variables, and parameters are summarized in the [National COVID Epi Model: Provincial model - Supplementary information](http://sacovid19mc.github.io/supplementaryInformation).

## Set-up

To run the code in this repository, you will require the following software:

- [R](http://r-project.org/)
- [R studio](https://rstudio.com/)
- a C compiler, e.g., [gcc](https://gcc.gnu.org/)

Once these are installed, the script <./packages.R> can be run from within R studio to install any required R packages that are not already installed on your computer.

Depending on the number of cores you have available, you may want to change the number of cores used for stochastic runs on line 32. If you have limited computational power, you may also want to reduce the number of iterations for stochasitc sampling.

An example session for which the code successfully runs has the following session information:

```
R version 3.6.3 (2020-02-29)
Platform: x86_64-apple-darwin15.6.0 (64-bit)
Running under: macOS Catalina 10.15.5

Matrix products: default
BLAS:   /System/Library/Frameworks/Accelerate.framework/Versions/A/Frameworks/vecLib.framework/Versions/A/libBLAS.dylib
LAPACK: /Library/Frameworks/R.framework/Versions/3.6/Resources/lib/libRlapack.dylib

locale:
[1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8

attached base packages:
[1] parallel  stats     graphics  grDevices utils     datasets  methods  
[8] base     

other attached packages:
 [1] scales_1.1.1      plotly_4.9.2.1    gridExtra_2.3     doParallel_1.0.15
 [5] iterators_1.0.12  foreach_1.5.0     rstudioapi_0.11   openxlsx_4.1.5   
 [9] EnvStats_2.3.1    readxl_1.3.1      ggplot2_3.3.2     adaptivetau_2.2-3
[13] deSolve_1.28     

loaded via a namespace (and not attached):
 [1] zip_2.0.4         Rcpp_1.0.4.6      cellranger_1.1.0  pillar_1.4.4     
 [5] compiler_3.6.3    tools_3.6.3       digest_0.6.25     viridisLite_0.3.0
 [9] jsonlite_1.7.0    lifecycle_0.2.0   tibble_3.0.1      gtable_0.3.0     
[13] pkgconfig_2.0.3   rlang_0.4.6       cli_2.0.2         curl_4.3         
[17] httr_1.4.1        withr_2.2.0       dplyr_1.0.0       htmlwidgets_1.5.1
[21] generics_0.0.2    vctrs_0.3.1       hms_0.5.3         grid_3.6.3       
[25] tidyselect_1.1.0  data.table_1.12.8 glue_1.4.1        R6_2.4.1         
[29] fansi_0.4.1       farver_2.0.3      tidyr_1.1.0       purrr_0.3.4      
[33] readr_1.3.1       magrittr_1.5      htmltools_0.5.0   codetools_0.2-16 
[37] ellipsis_0.3.1    assertthat_0.2.1  colorspace_1.4-1  labeling_0.3     
[41] stringi_1.4.6     lazyeval_0.2.2    munsell_0.5.0     crayon_1.3.4 
```

## Contact

If there are any queries regarding the model or the code, please contact us via: <info@sacovid19mc.co.za>.