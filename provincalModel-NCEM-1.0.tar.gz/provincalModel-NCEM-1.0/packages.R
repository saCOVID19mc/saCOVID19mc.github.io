### Checks for required packages and installs if not present ###

## deSolve (for numerical integration of differential equations)
## adaptivetau (for stochastic simulation)
## ggplot2 (for visualization)
## readxl (for reading in xlsx files)
## EnvStats (for the triangular distribution)
## openxlsx (for reading in xlsx files)
## rstudioapi (for setting the correct working directory)
## doParallel (for running processes in parallel)
## gridExtra (for visualization)
## plotly (for visualization)
## scales (for visualization)

packs <- rownames(installed.packages()) # names of all installed packages
req <- c("deSolve", "adaptivetau", "ggplot2", 
         "readxl", "EnvStats", "openxlsx",
         "rstudioapi", "doParallel", 
         "gridExtra", "plotly", "scales") # packages required to run code
toInstall <- req[!is.element(req,packs)] # packages needing installation

if(length(toInstall)>0){
  print("The following packages are required and will be installed:")
  print(toInstall)
  install.packages(toInstall)
}

# clean up workspace:
rm(packs, req, toInstall)
