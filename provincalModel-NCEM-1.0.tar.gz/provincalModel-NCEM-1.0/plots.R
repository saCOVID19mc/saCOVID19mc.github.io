library(scales)
library(plotly)
library(gridExtra)

#National Plot
ASympOptN<-NatOptq[["ActSym"]]
ASympPesN<-NatPesq[["ActSym"]]
HospOptN<-NatOptq[["HospBeds"]]
HospPesN<-NatPesq[["HospBeds"]]
ICUOptN<-NatOptq[["ICUBeds"]]
ICUPesN<-NatPesq[["ICUBeds"]]
DeathOptN<-NatOptq[["CDeaths"]]
DeathPesN<-NatPesq[["CDeaths"]]

{
t<-73:254
med1O<-ASympOptN[t,3]
low1O<-ASympOptN[t,1]
upp1O<-ASympOptN[t,5]
med1P<-ASympPesN[t,3]
low1P<-ASympPesN[t,1]
upp1P<-ASympPesN[t,5]

med2O<-HospOptN[t,3]
low2O<-HospOptN[t,1]
upp2O<-HospOptN[t,5]
med2P<-HospPesN[t,3]
low2P<-HospPesN[t,1]
upp2P<-HospPesN[t,5]

med3O<-ICUOptN[t,3]
low3O<-ICUOptN[t,1]
upp3O<-ICUOptN[t,5]
med3P<-ICUPesN[t,3]
low3P<-ICUPesN[t,1]
upp3P<-ICUPesN[t,5]

med4O<-DeathOptN[t,3]
low4O<-DeathOptN[t,1]
upp4O<-DeathOptN[t,5]
med4P<-DeathPesN[t,3]
low4P<-DeathPesN[t,1]
upp4P<-DeathPesN[t,5]


dates<-as.Date(73:254,origin="2020-03-21")

color_list <- c("blue", "red")
label_list<-c("Optimistic", "Pessimistic")
color_list2 <- c("blue", "steelblue")
label_list2<-c("", "")

#Nat
p1 <- ggplot() + 
  geom_line(aes(y=med1O, x=dates, color = "blue"))+
  geom_line(aes(y=med1P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low1O, ymax=upp1O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low1P, ymax=upp1P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "Active cases (Symptomatic)")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

p2 <- ggplot() + 
  geom_line(aes(y=med2O, x=dates, color = "blue"))+
  geom_line(aes(y=med2P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low2O, ymax=upp2O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low2P, ymax=upp2P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "Hospital (Non-ICU) Beds Needed")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

p3 <- ggplot() + 
  geom_line(aes(y=med3O, x=dates, color = "blue"))+
  geom_line(aes(y=med3P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low3O, ymax=upp3O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low3P, ymax=upp3P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "ICU Beds Needed")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

p4 <- ggplot() + 
  geom_line(aes(y=med4O, x=dates, color = "blue"))+
  geom_line(aes(y=med4P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low4O, ymax=upp4O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low4P, ymax=upp4P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "Cumulative Deaths")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

grid.arrange(p1, p2, p3, p4, nrow = 2, top="National")
}

##Provincial Plots ############

for (n in 1:N){
ASympOptP<-optprov[[n]][["ActSym"]]
ASympPesP<-pesprov[[n]][["ActSym"]]
HospOptP<-optprov[[n]][["HospBeds"]]
HospPesP<-pesprov[[n]][["HospBeds"]]
ICUOptP<-optprov[[n]][["ICUBeds"]]
ICUPesP<-pesprov[[n]][["ICUBeds"]]
DeathOptP<-optprov[[n]][["CDeaths"]]
DeathPesP<-pesprov[[n]][["CDeaths"]]

{
t<-73:254
med1O<-ASympOptP[t,3]
low1O<-ASympOptP[t,1]
upp1O<-ASympOptP[t,5]
med1P<-ASympPesP[t,3]
low1P<-ASympPesP[t,1]
upp1P<-ASympPesP[t,5]

med2O<-HospOptP[t,3]
low2O<-HospOptP[t,1]
upp2O<-HospOptP[t,5]
med2P<-HospPesP[t,3]
low2P<-HospPesP[t,1]
upp2P<-HospPesP[t,5]

med3O<-ICUOptP[t,3]
low3O<-ICUOptP[t,1]
upp3O<-ICUOptP[t,5]
med3P<-ICUPesP[t,3]
low3P<-ICUPesP[t,1]
upp3P<-ICUPesP[t,5]

med4O<-DeathOptP[t,3]
low4O<-DeathOptP[t,1]
upp4O<-DeathOptP[t,5]
med4P<-DeathPesP[t,3]
low4P<-DeathPesP[t,1]
upp4P<-DeathPesP[t,5]


dates<-as.Date(73:254,origin="2020-03-21")

color_list <- c("blue", "red")
label_list<-c("Optimistic", "Pessimistic")
color_list2 <- c("blue", "steelblue")
label_list2<-c("", "")


p1 <- ggplot() + 
  geom_line(aes(y=med1O, x=dates, color = "blue"))+
  geom_line(aes(y=med1P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low1O, ymax=upp1O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low1P, ymax=upp1P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "Active cases (Symptomatic)")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

p2 <- ggplot() + 
  geom_line(aes(y=med2O, x=dates, color = "blue"))+
  geom_line(aes(y=med2P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low2O, ymax=upp2O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low2P, ymax=upp2P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "Hospital (Non-ICU) Beds Needed")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

p3 <- ggplot() + 
  geom_line(aes(y=med3O, x=dates, color = "blue"))+
  geom_line(aes(y=med3P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low3O, ymax=upp3O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low3P, ymax=upp3P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "ICU Beds Needed")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

p4 <- ggplot() + 
  geom_line(aes(y=med4O, x=dates, color = "blue"))+
  geom_line(aes(y=med4P, x=dates, color = "red"))+
  geom_ribbon(aes(ymin=low4O, ymax=upp4O, x=dates, fill = "blue"), alpha = 0.2)+
  geom_ribbon(aes(ymin=low4P, ymax=upp4P, x=dates, fill = "red"), alpha = 0.2)+
  scale_fill_manual(values=(color_list), labels=label_list) + scale_color_manual(values=color_list,guide=FALSE)+
  labs(x="", y="", fill="",title = "Cumulative Deaths")+
  scale_y_continuous(name="", labels = comma)+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y") +
  theme_light(base_size = 9)

grid.arrange(p1, p2, p3, p4, nrow = 2, top=pvxy[n,1])
}
}









