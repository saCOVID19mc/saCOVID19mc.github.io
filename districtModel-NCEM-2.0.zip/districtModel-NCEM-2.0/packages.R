### Checks for required packages and installs if not present ###

## deSolve (for numerical integration of differential equations)
## adaptivetau, JuliaCall, diffeqr (for stochastic simulation)
## ggplot2, plotly, scales, gridExtra  (for visualization)
## readxl, openxlsx (for reading in xlsx files)
## EnvStats (for the triangular distribution)
## rstudioapi (for setting the correct working directory)
## doParallel (for running processes in parallel)
## tidyverse (for data wrangling)
## glue, crayon (for messaging)

library(pacman)
p_load(tidyverse, 
       crayon, 
       adaptivetau, 
       deSolve, 
       diffeqr, 
       ggplot2, 
       glue, 
       readxl, 
       openxlsx, 
       EnvStats, 
       JuliaCall, 
       argparser, 
       doParallel)
