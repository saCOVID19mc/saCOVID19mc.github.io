#!/usr/bin/env Rscript

#National COVID-19 Epi Model (NCEM)
#https://www.nicd.ac.za/diseases-a-z-index/covid-19/surveillance-reports/
#Supporting documents: https://github.com/saCOVID19mc/districtModel

#Model Characteristics: 
#Spatial Granularity: District  
#Disease: COVID-19
#Time Frame (Data): 2020-03-20 - 2021-03-19
#Notes: The model structure is written in R. 
# Simulations are run in R with a C compiler. 

#### Install and load packages####
source("packages.R")

numCores <-detectCores() #Set number of cores for execution of stochastic runs in parallel
n_iterations <- 10000 #set no. of iterations for stochastic runs

# ************************************************************************************* # #YES
#### Set working directory, read in C files ####
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) # set wd to source file
system("R CMD SHLIB eq0.c")     # compiles c code
dyn.load("eq0.so")              # loads compiled code to memory (.so - OS X, .dll - Windows)

#### Model start-up definitions####
N<-52   # number of patches
B<-21   # number of variables per patch
A<-40  # number of transitions per patch
V<-N*B # total number of variables
L<-N*A #total number of transitions
sday<-20
startyear=sday/365 # starting year of simulation 1=2020-03-01
tyears<-(52*7)/365 # total years of simulation 1
dtout<-1/365 # output timestep
tsteps<-round(tyears/dtout) # number of time steps
time<-startyear+seq(0,tyears,dtout) # time vector

# Call C function from eq0.so in R
EQ<-function(L, N, oldeq, transit,transitionsiu1,transitionsiu2,transitionsiv1,transitionsiv2){
  len<-length(oldeq)
  .C("EQ",
     as.integer(L),
     as.integer(N),
     as.double(oldeq),
     as.double(transit),
     as.integer(transitionsiu1),
     as.integer(transitionsiu2),
     as.integer(transitionsiv1),
     as.integer(transitionsiv2),
     as.double(vector("double",length = len))
  )[[9]]
  
}

#### Import data ####
source("data_district.R")

population<-pop$population #population by district 

#### Define variables #### 
# ************************************************************************************* #
# COVID -19
# 1=S: uninfected non-immune
# 2=E: infected & exposed
# 3=Ia: asymptomatic
# 4=Ip: pre-symptomatic and infectious 
# 5=Im: mild and infectious
# 6=Is: severe and infectious
# 7=H1: severe treated in hospital (non-ICU)
# 8=H2: critical entry into hospital (non-ICU)
# 9=ICUVd: ventilator-resourced ICU, destined to die  (ICU) :-(
# 10=ICUVr: ventilator-resourced ICU, destined to be discharged  (ICU)
# 11=H3:  critical stepdown from ICU to hosp (non-ICU)
# 12=Removed: holds non-infectious cases and discarges
# 13=Died: Deaths
# 14=Imdet Positive confirmed mild cases | test seeking
# 15=Isdet Positive confirmed severe/critical cases | hospitalisation
# 16=ICUnotVd: non-ventilator-resourced ICU, destined to die :-(
# 17=ICUnotVr: non-ventilator-resourced ICU, destined to be discharged
# 18=Sev2: overflow from hospital
# 19=Wv: overflow from ventilator-resourced ICU
# 20=WnotV: overflow from non-ventilator-resourced-ICU
# 21=IsnotT: Severe infection not seeking treatment


covpop<-c(1:12,16:21) #population alive

#### Define indices ####
# ************************************************************************************* #
varind<-matrix(0,nrow=B,ncol=N)
traind<-matrix(0,nrow=A,ncol=N)
for (n in 1:N){
  for (b in 1:B){
    varind[b,n]<-(n-1)*B+b
  }
  for (a in 1:A){
    traind[a,n]<-(n-1)*A+a
  }
}

#### Define transitions #### 
# ************************************************************************************* #
# first transition is given without index
transitions =ssa.maketrans(V,rbind(varind[4,1], +1)) # example
for (n in 1:N){
  #Seed & Imports
  transitions[traind[1,n]]<-ssa.maketrans(V,rbind(varind[1,n], 0,varind[5,n], +1)) # imported cases -> Im=5 
  transitions[traind[2,n]]<-ssa.maketrans(V,rbind(varind[1,n], 0,varind[6,n], +1)) # imported cases -> Is=6 
  transitions[traind[3,n]]<-ssa.maketrans(V,rbind(varind[1,n], 0,varind[8,n], +1)) # imported cases -> H2=8
  
  #Incidence
  transitions[traind[4,n]]<-ssa.maketrans(V,rbind(varind[1,n], -1,varind[2,n],+1)) # incidence S to E 
  transitions[traind[5,n]]<-ssa.maketrans(V,rbind(varind[2,n], -1,varind[3,n],+1)) # incubation E to A  
  transitions[traind[6,n]]<-ssa.maketrans(V,rbind(varind[2,n], -1,varind[4,n],+1)) # incubation E to Ip 
  transitions[traind[7,n]]<-ssa.maketrans(V,rbind(varind[4,n], -1,varind[5,n],+1)) # mild infection Ip to Im
  transitions[traind[8,n]]<-ssa.maketrans(V,rbind(varind[4,n], -1,varind[6,n],+1)) # severe infection Ip to Ist
  transitions[traind[9,n]]<-ssa.maketrans(V,rbind(varind[4,n], -1,varind[21,n],+1)) # severe infection Ip to IsnotT
  
  #Treatment seeking
  transitions[traind[10,n]]<-ssa.maketrans(V,rbind(varind[6,n], -1,varind[7,n],+1)) # hosp severe Ist to H1
  transitions[traind[11,n]]<-ssa.maketrans(V,rbind(varind[6,n], -1,varind[8,n],+1)) # hosp critical infection Ist to H2 (non-ICU)
  transitions[traind[12,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[9,n],+1)) # icu critical/ventilated infection (destined to die)  H2 to ICUVd
  transitions[traind[13,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[10,n],+1)) # icu critical/ventilated infection (destined to be discharged) H2 to ICUVr
  transitions[traind[14,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[16,n],+1))  # icu critical/not ventilated infection (destined to die) H2 to ICUnotVd
  transitions[traind[15,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[17,n],+1))  # icu critical/not ventilated infection (destined to be discharged)  H2 to ICUnotVr
  
  #Natural Outcomes
  transitions[traind[16,n]]<-ssa.maketrans(V,rbind(varind[3,n], -1,varind[12,n],+1)) # natural recovery A to R
  transitions[traind[17,n]]<-ssa.maketrans(V,rbind(varind[5,n], -1,varind[12,n],+1)) # natural recovery Im to R   
  transitions[traind[18,n]]<-ssa.maketrans(V,rbind(varind[21,n], -1,varind[12,n],+1)) # natural recovery SevnotT to R
  transitions[traind[19,n]]<-ssa.maketrans(V,rbind(varind[21,n], -1,varind[13,n],+1)) # death SevnotT to D
  
  #Hospital outcomes
  transitions[traind[20,n]]<-ssa.maketrans(V,rbind(varind[7,n], -1,varind[12,n],+1)) # severe discharged H1 to R
  transitions[traind[21,n]]<-ssa.maketrans(V,rbind(varind[7,n], -1,varind[13,n],+1)) # severe died H1 to D
  transitions[traind[22,n]]<-ssa.maketrans(V,rbind(varind[9,n], -1,varind[13,n],+1)) # critical ventilated died ICUVd to D
  transitions[traind[23,n]]<-ssa.maketrans(V,rbind(varind[10,n], -1,varind[11,n],+1)) # stepdown critical ventilated to non-ICU,ICUVr to H3
  transitions[traind[24,n]]<-ssa.maketrans(V,rbind(varind[11,n], -1,varind[12,n],+1)) # critical discharged H3 to R
  transitions[traind[25,n]]<-ssa.maketrans(V,rbind(varind[16,n], -1,varind[13,n],+1)) # critical not ventilated died ICUnotVd to D
  transitions[traind[26,n]]<-ssa.maketrans(V,rbind(varind[17,n], -1,varind[11,n],+1)) # stepdown critical not ventilated to non-ICU, ICUnotVr to H3
  
  #Detection (REVISE)
  transitions[traind[27,n]]<-ssa.maketrans(V,rbind(varind[14,n], 0,varind[14,n], +1)) # inflow:  mild cases for testing -> Imdet=13 
  transitions[traind[28,n]]<-ssa.maketrans(V,rbind(varind[14,n], -1,varind[14,n], 0)) # outflow: confirmed mild cases  Imdet=13 ->
  transitions[traind[29,n]]<-ssa.maketrans(V,rbind(varind[15,n], 0,varind[15,n], +1)) # inflow:  severe/critical cases for testing -> Isdet=14  
  transitions[traind[30,n]]<-ssa.maketrans(V,rbind(varind[15,n], -1,varind[15,n], 0)) # outflow: confirmed severe/critical cases  Isdet=14 -> 
  
  #Capacity constraints: hospital beds
  transitions[traind[31,n]]<-ssa.maketrans(V,rbind(varind[6,n], -1,varind[18,n],+1))  # overflow SevT to Sev2 (non-critical)
  transitions[traind[32,n]]<-ssa.maketrans(V,rbind(varind[6,n], -1,varind[18,n],+1))  # overflow SevT to Sev2 (critical)
  transitions[traind[33,n]]<-ssa.maketrans(V,rbind(varind[18,n], -1,varind[12,n],+1)) # natural recovery Sev2 to R
  transitions[traind[34,n]]<-ssa.maketrans(V,rbind(varind[18,n], -1,varind[13,n],+1)) # death Sev2 to D
  
  #Capacity constraints: ICU beds
  transitions[traind[35,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[19,n],+1))  # waiting room H2 to Wv
  transitions[traind[36,n]]<-ssa.maketrans(V,rbind(varind[19,n], -1,varind[12,n],+1)) # discharge Wv to R
  transitions[traind[37,n]]<-ssa.maketrans(V,rbind(varind[19,n], -1,varind[13,n],+1)) # death Wv to D
  transitions[traind[38,n]]<-ssa.maketrans(V,rbind(varind[8,n], -1,varind[20,n],+1))  # waiting room H2 to WnotV
  transitions[traind[39,n]]<-ssa.maketrans(V,rbind(varind[20,n], -1,varind[12,n],+1)) # discharge WnotV to R
  transitions[traind[40,n]]<-ssa.maketrans(V,rbind(varind[20,n], -1,varind[13,n],+1)) # death WnotV to D
}

#Alternate formulation of transitions matrix (used in epimodel function)
transitions2<-NULL
for (i in 1: length(transitions)){
  transitions2<-rbind(transitions2,cbind(as.integer(names(transitions[[i]]))[1],as.integer(names(transitions[[i]]))[2], transitions[[i]][1], transitions[[i]][2]))
}
row.names(transitions2)<-NULL
transitionsiu1<-transitions2[,1]
transitionsiu2<-transitions2[,2]
transitionsiv1<-transitions2[,3]
transitionsiv2<-transitions2[,4]


#### Define parameters #### 
# ************************************************************************************* #
pars = {list(
  gamma1 = parameters[parameters$Name=="gamma1",3],  #1/non-infectious incubation duration
  gamma2 = parameters[parameters$Name=="gamma2",3],  #1/infectious incubation duration
  taum=parameters[parameters$Name=="taum",3], # 1/trt seeking mild
  r1=parameters[parameters$Name=="r1",3], # 1/dur infectiousness (asymptomatic)
  r2=parameters[parameters$Name=="r2",3], # 1/dur infectiousness (mild)
  taus=parameters[parameters$Name=="taus",3], # 1/trt seeking severe
  pa = parameters[parameters$Name=="pa",3], # asymptomatic proportion of cases
  tauicu = parameters[parameters$Name=="tauicu",3], # 1/ duration of progression of severe cases to critical 
  zeta1 = parameters[parameters$Name=="zeta1",3], #relative infectiousness of asymptomatic population
  r3=parameters[parameters$Name=="r3",3], #1/dur stay hospital (severe)
  deltam=parameters[parameters$Name=="deltam",3], #1/lead time to test result (mild)
  deltas=parameters[parameters$Name=="deltas",3], #1/lead time to test result (severe)
  r5=parameters[parameters$Name=="r5",3], #1/dur stay hosp (post critical)
  r6=parameters[parameters$Name=="r6",3], #1/dur infectiousness (severe untreated)
  muv=parameters[parameters$Name=="muv",3],       #1/time to death on ventilator
  munotv=parameters[parameters$Name=="munotv",3], #1/time to death not on ventilator
  r8=parameters[parameters$Name=="r8",3],   #1/time to recovery for severe
  r9=parameters[parameters$Name=="r9",3],   #1/time to recovery for those needing ventilators
  r10=parameters[parameters$Name=="r10",3], #1/time to recovery for those needing ICU (non-ventilator)
 sc2=parameters[parameters$Name=="sc2",3], #Scale factor for ventilator-resourced ICU
 sc3=parameters[parameters$Name=="sc3",3]  #Scale factor for non-ventilator-resourced-ICU
);
} 
pars$r3<-rep(pars$r3,N)



#Capacity by district (default is unlimited)
pars$gen_capacity=capacity$Hosp_unltd
pars$icu_capacity=capacity$ICU_unltd

pars$R0<-disR0g$R0[1:N]  #district R0
pars$L5Rt<-disR0g$L5Rt[1:N]  #district Level 5 Rt
pars$IncL4<-disR0g$Res_IncL4[1:N] 
pars$IncL3_12<-disR0g$Res_IncL3_12[1:N]
pars$IncL3_345<-disR0g$Res_IncL3_345[1:N]
pars$IncL2<-disR0g$Res_IncL2[1:N]
pars$gmL3_12<-disR0g$`Level 3_12`[1:N]
pars$gmL3_345<-disR0g$`Level 3_345`[1:N]
pars$gmL2<-disR0g$`Level 2`[1:N]
pars$beta_slope<-disR0g$beta_slope[1:N]
pars$beta_intercept<-disR0g$beta_intercept[1:N]


#### Inputs to transition rates (blank)####
# ************************************************************************************* #

inputs<-function(parmal, scenario){
  
}

# ************************************************************************************* # #YES
#### Base functions ####

# ************************************************************************************* #
# Function to calculate transition rates, given variables and parameters
# ************************************************************************************* #
timesCovratesCalled<-0
mvt<-list(mvtL0, mvtpreL5, mvtL5, mvtL4, mvtL3_12, mvtL3_345, mvtL2) #Make a list of average mobility matrices

# TRANSITIONS function
covrates_het <- function(x, input, parmal, t,ti, scenario) {
  timesCovratesCalled <<- timesCovratesCalled + 1
  with(as.list(c( parmal, scenario)),
       {
         t_internal<-(ti-1)*dtout+t+startyear
         
         #Set up matrices
         popc<-c(rep(0,N))    # population sizes  
         import<-seed<-c(rep(0,N))
         
         #Call movement matrices
         mvt_ind<-(t_internal< 23/365)*1 +              #23/03
           (t_internal>=23/365)*(t_internal<27/365)*2 + #27/03
           (t_internal>=27/365)*(t_internal<62/365)*3 + #01/05
           (t_internal>=62/365)*(t_internal<93/365)*4 + #01/06
           (t_internal>=93/365)*(t_internal<123/365)*5 + #01/07
           (t_internal>=123/365)*(t_internal<171/365)*6 + #18/08
           (t_internal>=171/365)*7 
         
         
      
         
         #scenario set up - dates reference 1/365 = 1 March 2020
         beta<-beta0
         beta<-(t_internal<27/365)*beta0 + 
           (t_internal>=27/365)*(t_internal<62/365)*betaL5+
           (t_internal>=62/365)*(t_internal<93/365)*betaL4+
           (t_internal>=93/365)*(t_internal<123/365)*betaL3_12 +
           (t_internal>=123/365)*(t_internal<171/365)*betaL3_345 +
           (t_internal>=171/365)*betaL2 
         
         #i1 Use Scenario with reduced access to treatment in surge and base parameters
         if (i1==1){
           pts<-ifelse((t_internal>pts_peak$t_st/365)&(t_internal<pts_peak$t_end/365),pts2, pts)
           
         }
         #i2 Needs Scenario with 100% access to treatment and revised hospital parameters
         if (i2==1){
          pts<-rep(1,N)
          r3<-rep(365/8, N)
          muv<-365/14
          munotv<-365/11
          r9<-365/19
         }
         
         
         
         # Excess Capacity segment
         avail1 = rep(1, N)
         avail2 = rep(1, N)
         
         
         # Hospital beds
         beds_occupied <- Reduce("+", lapply(c(7, 8, 11, 19, 20), function(ind){x[varind[ind,]]})) %>% unname
         # Sev to H1 and H2
         proposed_enter = unname(taus*x[varind[6,]]/365)
         proposed_exit = unname(
           tauicu*x[varind[8, ]]+  # H2 to ICU
             r3*x[varind[7, ]]+      # H1 to R,D
             r5*x[varind[11, ]]+     # H3 to R
             r9*x[varind[19, ]]+     # Wv to R,D
             r10*x[varind[20, ]]     # WnotV to R,D
         )/365
         
         violation = which(beds_occupied - proposed_exit + proposed_enter > gen_capacity)
         avail1[violation] = (gen_capacity[violation] - beds_occupied[violation] + proposed_exit[violation]) / proposed_enter[violation]
         
         
         # ICU
         ICU_occupied <- Reduce("+", lapply(c(9, 10, 16, 17), function(ind){x[varind[ind,]]})) %>% unname
         # H2 to all ICUs
         proposed_enter = unname(tauicu*x[varind[8,]]/365)
         proposed_exit = unname(
           muv*x[varind[9, ]] +     # ICUVd to D
             r9*x[varind[10, ]] +     # ICUVr to H3
             munotv*x[varind[16, ]] + # ICUnotVd to D
             r10*x[varind[17, ]]      # ICUnotVr to H3
         )/365
         
         violation = which(ICU_occupied -proposed_exit + proposed_enter > icu_capacity)
         avail2[violation] = (icu_capacity[violation] - ICU_occupied[violation] + proposed_exit[violation]) / proposed_enter[violation]
         
         # Correct for zero-capacity situations
         avail1[which(gen_capacity == 0)] = 0
         avail2[which(icu_capacity == 0)] = 0
         
         #Living population
         popc <- Reduce("+", lapply(covpop, function(ind) x[varind[ind,]])) %>% unname
         
         Infectious_n <- (zeta1*x[varind[3,]] + zeta1*x[varind[4,]] + x[varind[5,]] + x[varind[6,]] + x[varind[18,]] + x[varind[21,]])
         
         vee <- beta*(Infectious_n/popc)
         movmat <- mvt[[mvt_ind]]
         foi_o <- (sweep(movmat, MARGIN = 2, vee, `*`) %>% rowSums())
         foi_het<-foi_o*((x[varind[1,]]/popc)^k)
         foi<-foi_het
         
         if (t_internal<(70/365)) {
           import <- seedfac * sapply(1:N, function(n){approx(as.data.frame(seeddata)$t, as.data.frame(seeddata)[,n+1], t_internal, rule=2)$y})
         }
         
         tranrate <- array(c(
           #Seed & Imports
           pm*import, #  importation to Im       1
           ps*import, #importation to Is 1       2
           (1-pm-ps)*import, #importation to H2  3
           #Incidence
           foi*x[varind[1,]],       # incidence S to E     4
           pa*gamma1*x[varind[2,]],       # incubation E to A     5
           (1-pa)*gamma1*x[varind[2,]],       # incubation E to Ip     6
           pm*gamma2*x[varind[4,]],       # mild infection Ip to Im       7
           (1-pm)*pts*gamma2*x[varind[4,]],       #  severe infection Ip to Ist       8
           (1-pm)*(1-pts)*gamma2*x[varind[4,]],       #  severe infection Ip to IsnotT       9
           
           #Treatment Seeking
           avail1*(1-(1-pm-ps)/(1-pm))*taus*x[varind[6,]],       #  hosp severe Ist to H1        10
           avail1*((1-pm-ps)/(1-pm))*taus*x[varind[6,]],   # hosp critical infection Is to H2 (non-ICU)    11
           avail2*pv*pd2v*tauicu*x[varind[8,]],       # icu critical ventilated infection (destined to die) H2 to ICUvd    12
           avail2*pv*(1-pd2v)*tauicu*x[varind[8,]],       # icu critical ventilated infection (destined to be discharged) H2 to ICUvr  13
           avail2*(1-pv)*pd2notv*tauicu*x[varind[8,]],     #icu critical non-ventilated infection (destined to die) H2 to ICUnotVd   14
           avail2*(1-pv)*(1-pd2notv)*tauicu*x[varind[8,]], # icu critical non-ventilated infection (destined to discharged) H2 to ICUnotVr   15
           #Natural Outcomes
           r1*x[varind[3,]],       # natural recovery A (asymp) to R   16
           r2*x[varind[5,]],         # natural recovery Im to R         17
           (1-((1-pm-ps)/(1-pm)+(1-(1-pm-ps)/(1-pm))*(0.2+0.8*0.9)))*r8*x[varind[21,]],       # natural recovery SevnotT to R  18
           ((1-pm-ps)/(1-pm)+(1-(1-pm-ps)/(1-pm))*(0.2+0.8*0.9))*r8*x[varind[21,]], # death SevnotT to D         19
           
           #Hospital outcomes
           (1-pd1)*r3*x[varind[7,]],         # severe discharged H1 to R         20
           pd1*r3*x[varind[7,]], # severe died H1 to D         21
           muv*x[varind[9,]],         #     critical ventilated died ICUVd to D  22
           r9*x[varind[10,]],         #    stepdown critical ventilated to non-ICU, ICUVr to H3  23
           r5*x[varind[11,]],  #      critical discharged H3 to R   24
           munotv*x[varind[16,]],    # critical not ventilated died ICUnotVd to D  25
           r10*x[varind[17,]],        # stepdown critical not ventilated to non-ICU, ICUnotVr to H3   26
           
           #Detection
           pdetm*pm*gamma2*x[varind[4,]], # inflow:  mild cases for testing -> Imdet=14   27
           deltam*x[varind[14,]], # outflow: confirmed mild cases (seek+test) Imdet=14 ->  28
           pdets*avail1*taus*x[varind[6,]], # inflow:  severe/critical cases for testing upon entry to hosp -> Isdet=15  29
           deltas*x[varind[15,]], # outflow: confirmed severe cases  (test) Isdet=15 ->   30
           
           #Capacity constraints: hospital beds
           (1-avail1)*(1-(1-pm-ps)/(1-pm))*taus*x[varind[6,]],     # Sev to Sev2 (non-critical)      31
           (1-avail1)*((1-pm-ps)/(1-pm))*taus*x[varind[6,]], # Sev to Sev2 (critical)  32
           (1-((1-pm-ps)/(1-pm)+(1-(1-pm-ps)/(1-pm))*(0.2+0.8*0.9)))*r8*x[varind[18,]],               # Sev2 to R   33 Old (1-min(sc1*0.5*(pd2v+pd2notv),1))
           ((1-pm-ps)/(1-pm)+(1-(1-pm-ps)/(1-pm))*(0.2+0.8*0.9))*r8*x[varind[18,]],       # Sev2 to D   34 Old - min(sc1*0.5*(pd2v+pd2notv),1)*
           
           #Capacity constraints: ICU beds
           (1-avail2)*pv*tauicu*x[varind[8,]],   # waiting room H2 to Wv  35
           (1-min(sc2*pd2v,1))*r9*x[varind[19,]],   # Discharge Wv to R   36
           min(sc2*pd2v,1)*r9*x[varind[19,]],      # Death Wv to D   37
           (1-avail2)*(1-pv)*tauicu*x[varind[8,]],  # waiting room H2 to WnotV  38
           (1-min(sc3*pd2notv,1))*r10*x[varind[20,]],             # Discharge WnotV to R   39
           min(sc3*pd2notv,1)*r10*x[varind[20,]]   # Death WnotV to D   40
         ), dim=c(N, A))
         tranrate <- c(t(tranrate))
         return(tranrate)
       })
}

# POST PROCESSING function
postproc <- function(parpro,out,tran) {
  with(as.list(c( parpro)),
       {
         # ************************************************************************************* #
         # for outputting the  time series for each patch
         # ************************************************************************************* #
         
         # Case outputs
         deathuntrt_pred<-vent_overflow<-icu_overflow<-hosp_overflow<-ventilators<-deathex_vent_pred<-deathex_icu_pred<-deathex_hosp_pred<-deathicu_novent_pred<-deathicu_vent_pred<-deathgen_pred<-deathicu_pred<-admicu_pred<-admit_pred<-inc_pred<-asym_pred<-hosp_beds<-icu_beds<-mdet_pred<-sdet_pred<-prev_pred<-mild_pred<-sev_pred<-crit_pred<-death_pred<-matrix(0,nrow=length(out[,1]),ncol=N)
         for (n in 1:N){
           mild_pred[,n]<-tran[,c(traind[7,n])]/365 
           sev_pred[,n]<-(tran[,c(traind[8,n])]+tran[,c(traind[9,n])])/365 
           crit_pred[,n]<-(tran[,c(traind[11,n])])/365 
           asym_pred[,n]<-(tran[,c(traind[5,n])])/365 
           death_pred[,n]<-rowSums(tran[,c(traind[c(19,21,22,25,34,37,40),n])])/365
           hosp_beds[,n]<-rowSums(out[,c(varind[c(7,8,11,19,20),n])+1])
           icu_beds[,n]<-rowSums(out[,c(varind[c(9,10,16,17),n])+1])
           prev_pred[,n]<-rowSums(out[,c(varind[c(2:11,16:21),n])+1])
           mdet_pred[,n]<-(tran[,c(traind[28,n])])/365 + tran[,c(traind[1,n])]
           sdet_pred[,n]<-(tran[,c(traind[30,n])])/365 + tran[,c(traind[2,n])] +tran[,c(traind[3,n])]
           inc_pred[,n]<-(tran[,c(traind[4,n])])/365 
           admit_pred[,n]<-(tran[,c(traind[10,n])])/365
           admicu_pred[,n]<-rowSums(tran[,c(traind[12:15,n])])/365
           deathuntrt_pred[,n]<-(tran[,c(traind[19,n])])/365
           deathgen_pred[,n]<-rowSums(tran[,c(traind[c(21,37,40),n])])/365
           deathicu_pred[,n]<-(tran[,c(traind[22,n])]+tran[,c(traind[25,n])])/365
           deathicu_vent_pred[,n]<-(tran[,c(traind[22,n])])/365
           deathicu_novent_pred[,n]<-(tran[,c(traind[25,n])])/365
           
           deathex_hosp_pred[,n]<-(tran[,c(traind[34,n])])/365
           deathex_icu_pred[,n]<-(tran[,c(traind[37,n])]+tran[,c(traind[40,n])])/365
           deathex_vent_pred[,n]<-(tran[,c(traind[37,n])])/365
           ventilators[,n]<-rowSums(out[,c(varind[c(9,10),n])+1])
           hosp_overflow[,n]<-out[,c(varind[18,n])+1]
           icu_overflow[,n]<-rowSums(out[,c(varind[c(19,20),n])+1])
           vent_overflow[,n]<-out[,c(varind[19,n])+1]
         }
         
         
         return(cbind(mild_pred,    #1
                      sev_pred,     #2
                      crit_pred,  #3
                      asym_pred, #4
                      death_pred,  #5
                      prev_pred, #6
                      hosp_beds, #7
                      icu_beds,  #8
                      mdet_pred, #9
                      sdet_pred,  #10
                      inc_pred, #11
                      admit_pred, #12
                      admicu_pred, #13
                      deathgen_pred, #14
                      deathicu_pred, #15
                      deathicu_vent_pred, #16
                      deathicu_novent_pred, #17
                      deathex_hosp_pred, #18
                      deathex_icu_pred, #19
                      deathex_vent_pred, #20
                      ventilators, #21
                      hosp_overflow, #22
                      icu_overflow, #23
                      vent_overflow, #24
                      deathuntrt_pred #25
                      
         ))
         
       })
}

ti<-1

# ODE SOLVER

epiModel<-function(t,state, parode,input, scenario) 
{ 
  
  with(as.list(c(state, parode)),
       {
         
         #   # ************************************************************************************* #
         #   # define variables
         #   # ************************************************************************************* #
         
         Z=state
         
         # rates of change
         ti<-1
         transit<-covrates(Z[1:V],input,parode,Z[V+1],ti, scenario)  
         
         if (sum(is.na(transit))>0)  {
           stop("transit NA   ",Z[V+1], "                                      ", 
                as.data.frame(transit))
         }
         
         transit2<-transit
         
         eq<-rep(0.0, V)
         
         eq<-EQ(L, N, eq, transit2,transitionsiu1,transitionsiu2,transitionsiv1,transitionsiv2)
         
         eq[V+1]<-1
         
         dZ<-eq
         
         # return the rate of change
         list(c(dZ))
       }
  ) 
}

# MODEL RUN FUNCTION
run_o <- function(parrun, scenario){
  
  # ************************************************************************************* #
  # define initial conditions
  initcondrun<-NULL
  
  for (n in 1:N) { initcondrun<-c(initcondrun, c(rep(0,(B)))); 
  initcondrun[varind[3,n]]<-parrun$pa*seedfac[n]*as.numeric(infcases$infcases[n]);
  initcondrun[varind[4,n]]<-(1-parrun$pa)*seedfac[n]*as.numeric(infcases$infcases[n])  
  initcondrun[varind[1,n]]<-population[n] - initcondrun[varind[3,n]] - initcondrun[varind[4,n]]
  }
  
  # all initial conditions must be integers
  initoderun<-initcondrun
  staterun <- c(initoderun,0)
  ti<-1
  inp<-inputs(parrun)
  transitrun <- covrates(initoderun,inp,parrun,0,ti,scenario )
  
  #
  # # SOLVE THE ODEs and get output
  timesrun <- seq(0, tyears, by = dtout) # Model run time
  #Solve ODE
  outoderun <- ode(y = staterun, times = timesrun, func = epiModel, parms = parrun, method  = "vode", input=inp,scenario=scenario )
  # Compute transitions at each time step
  tranoderun<-matrix(0,nrow=length(outoderun[,1]),ncol=length(transitions))
  for (ti in 1:(tsteps+1)){
    tranoderun[ti,]<-t(covrates(outoderun[ti,2:(1+V)],inp,parrun,0,ti,scenario ))
  }
  #Compute outputs
  ppout<-postproc(parrun,outoderun,tranoderun)
  modeltimes<-outoderun[,1]+startyear
  
  mild_pred_ode<-ppout[,1:N]
  sev_pred_ode<-ppout[,(N+1):(2*N)]
  crit_pred_ode<-ppout[,(2*N+1):(3*N)]
  asym_pred_ode<-ppout[,(3*N+1):(4*N)]
  death_pred_ode<-ppout[,(4*N+1):(5*N)]
  prev_pred_ode<-ppout[,(5*N+1):(6*N)]
  hosp_beds_ode<-ppout[,(6*N+1):(7*N)]
  icu_beds_ode<-ppout[,(7*N+1):(8*N)]
  mdet_pred_ode<-ppout[,(8*N+1):(9*N)]
  sdet_pred_ode<-ppout[,(9*N+1):(10*N)]
  totinc_pred_ode<-ppout[,(10*N+1):(11*N)]
  admit_pred_ode<-ppout[,(11*N+1):(12*N)]
  admicu_pred_ode<-ppout[,(12*N+1):(13*N)]
  deathgen_pred_ode<-ppout[,(13*N+1):(14*N)]
  deathicu_pred_ode<-ppout[,(14*N+1):(15*N)]
  deathicu_vent_pred_ode<-ppout[,(15*N+1):(16*N)]
  deathicu_novent_pred_ode<-ppout[,(16*N+1):(17*N)]
  deathex_hosp_pred_ode<-ppout[,(17*N+1):(18*N)]
  deathex_icu_pred_ode<-ppout[,(18*N+1):(19*N)]
  deathex_vent_pred_ode<-ppout[,(19*N+1):(20*N)]
  ventilators_ode<-ppout[,(20*N+1):(21*N)]
  hosp_overflow_ode<-ppout[,(21*N+1):(22*N)]
  icu_overflow_ode<-ppout[,(22*N+1):(23*N)]
  vent_overflow_ode<-ppout[,(23*N+1):(24*N)]
  death_untrt_ode<-ppout[,(24*N+1):(25*N)]
  inc_pred_ode<-mild_pred_ode+sev_pred_ode
  
  
  
  COVout<-list(modeltimes, #1
               mild_pred_ode,#2
               sev_pred_ode,#3
               crit_pred_ode,#4
               asym_pred_ode,#5
               death_pred_ode,#6
               prev_pred_ode,#7
               hosp_beds_ode,#8
               icu_beds_ode,#9
               mdet_pred_ode,#10
               sdet_pred_ode,#11
               inc_pred_ode,#12
               totinc_pred_ode,#13
               outoderun, #14
               tranoderun, #15
               admit_pred_ode, #16
               admicu_pred_ode, #17
               deathgen_pred_ode, #18
               deathicu_pred_ode, #19
               deathicu_vent_pred_ode, #20
               deathicu_novent_pred_ode, #21
               deathex_hosp_pred_ode, #22
               deathex_icu_pred_ode, #23
               deathex_vent_pred_ode, #24
               ventilators_ode, #25
               hosp_overflow_ode, #26
               icu_overflow_ode, #27
               vent_overflow_ode, #28
               death_untrt_ode #29
  )
  
  
  
  
  return(COVout)
}

#set report time
dtimes<-format(as.Date(time*365,origin="2020-02-29"), "%d/%m/%Y")
dweeks<-dtimes[seq(1,length(dtimes),7)]
dtimes2<-as.Date(time*365,origin="2020-02-29")


#### Scenario definition ####

scenario<-matrix(0, 2, 2)
scenario[1,]<-c(1, 0)  #Use
scenario[2,]<-c(0, 1)  #Need

scenario<-cbind(i1=scenario[,1],i2=scenario[,2])

####Set up Projections Parameters ####

#Ascertainment for case detection
inf<-rep(4, N) #adjust inflation factor for all cases (A+S)
pars$pdetm<-1/inf # apply inflation factor to detection of all cases
pars$pdets<-1

#treatment Access during 4 week COVID peak incidence
pars$pts2[P[[1]]]<-provparam$pts2[1]
pars$pts2[P[[2]]]<-provparam$pts2[2]
pars$pts2[P[[3]]]<-provparam$pts2[3]
pars$pts2[P[[4]]]<-provparam$pts2[4]
pars$pts2[P[[5]]]<-provparam$pts2[5]
pars$pts2[P[[6]]]<-provparam$pts2[6]
pars$pts2[P[[7]]]<-provparam$pts2[7]
pars$pts2[P[[8]]]<-provparam$pts2[8]
pars$pts2[P[[9]]]<-provparam$pts2[9]

#Treatment Access before/after COVID peak incidence
pars$pts<- pars$pts2+0.5*(1-pars$pts2)

# Probability of severe infection treated in hospital
pars$ps<-rep(0.025, N) 

#Probability of critical infection 
pars$pc<-rep(0.01, N)
pars$pc[P[[1]]]<-provparam$pc[1]*pars$ps[P[[1]]]
pars$pc[P[[2]]]<-provparam$pc[2]*pars$ps[P[[2]]] 
pars$pc[P[[5]]]<-provparam$pc[3]*pars$ps[P[[5]]]
pars$pc[P[[6]]]<-provparam$pc[4]*pars$ps[P[[6]]] 
pars$pc[P[[7]]]<-provparam$pc[5]*pars$ps[P[[7]]] 
pars$pc[P[[8]]]<-provparam$pc[6]*pars$ps[P[[8]]] 
pars$pc[P[[3]]]<-provparam$pc[7]*pars$ps[P[[3]]] 
pars$pc[P[[4]]]<-provparam$pc[8]*pars$ps[P[[4]]] 
pars$pc[P[[9]]]<-provparam$pc[9]*pars$ps[P[[9]]] 

#Proportion of severe infection scaled for in/out of hospital
pars$ps<-pars$ps/pars$pts2
pars$pm<-1 - pars$ps - pars$pc  #Proportion of mild infections
pars$durinf<-(pars$zeta1*pars$pa/pars$r1 + pars$zeta1*(1-pars$pa)/pars$gamma2 + (1-pars$pa)*pars$pm/pars$r2 + (1-pars$pa)*(1-pars$pm)/pars$taus) #annual units

#Proportion Ventilated
pars$pv<-rep(0.3,N);
pars$pv[P[[1]]]<-provparam$pv[1]
pars$pv[P[[2]]]<-provparam$pv[2]
pars$pv[P[[3]]]<-provparam$pv[3]
pars$pv[P[[4]]]<-provparam$pv[4]
pars$pv[P[[5]]]<-provparam$pv[5]
pars$pv[P[[6]]]<-provparam$pv[6]
pars$pv[P[[7]]]<-provparam$pv[7]
pars$pv[P[[8]]]<-provparam$pv[8]
pars$pv[P[[9]]]<-provparam$pv[9]


#Defining effective contact rates between lockdown levels
pars$beta0<- pars$R0/pars$durinf
pars$betaL5<-pars$L5Rt/pars$durinf
pars$betaL4<-pars$betaL5*(1+pars$IncL4) 
pars$betaL4[P[[1]]]<-1.6/pars$durinf[P[[1]]]
pars$betaL4[P[[2]]]<-1.6/pars$durinf[P[[2]]]
pars$betaL4[P[[3]]]<-1.8/pars$durinf[P[[3]]]
pars$betaL4[P[[4]]]<-1.6/pars$durinf[P[[4]]]
pars$betaL4[P[[5]]]<-1.6/pars$durinf[P[[5]]]
pars$betaL4[P[[6]]]<-1.6/pars$durinf[P[[6]]]
pars$betaL4[P[[7]]]<-1.6/pars$durinf[P[[7]]]
pars$betaL4[P[[8]]]<-1.6/pars$durinf[P[[8]]]

pars$betaL3_12<-pars$beta_slope*(100+pars$gmL3_12)+pars$beta_intercept    
pars$betaL3_345<-pars$beta_slope*(100+pars$gmL3_345)+pars$beta_intercept   
pars$betaL2<-pars$beta_slope*(100+pars$gmL2)+pars$beta_intercept      
#matplot(t(cbind(pars$beta0, pars$betaL5, pars$betaL4, pars$betaL3_12, pars$betaL3_345, pars$betaL2)), ty="l")
#cbind(pars$beta0*pars$durinf,pars$betaL5*pars$durinf,pars$betaL4*pars$durinf,pars$betaL3_12*pars$durinf,pars$betaL3_345*pars$durinf,pars$betaL2*pars$durinf, districts$Province)

# Proportion Dying in general ward
pars$pd1<-rep(0.1,N)
pars$pd1[P[[1]]]<-provparam$pd1[1]
pars$pd1[P[[2]]]<-provparam$pd1[2]
pars$pd1[P[[3]]]<-provparam$pd1[3]
pars$pd1[P[[4]]]<-provparam$pd1[4]
pars$pd1[P[[5]]]<-provparam$pd1[5]
pars$pd1[P[[6]]]<-provparam$pd1[6]
pars$pd1[P[[7]]]<-provparam$pd1[7]
pars$pd1[P[[8]]]<-provparam$pd1[8]
pars$pd1[P[[9]]]<-provparam$pd1[9]

#Proportion in ICU dying on ventilator
pars$pd2v<-rep(0.45,N) 
pars$pd2v[P[[1]]]<-provparam$pd2v[1]
pars$pd2v[P[[2]]]<-provparam$pd2v[2]
pars$pd2v[P[[3]]]<-provparam$pd2v[3]
pars$pd2v[P[[4]]]<-provparam$pd2v[4]
pars$pd2v[P[[5]]]<-provparam$pd2v[5]
pars$pd2v[P[[6]]]<-provparam$pd2v[6]
pars$pd2v[P[[7]]]<-provparam$pd2v[7]
pars$pd2v[P[[8]]]<-provparam$pd2v[8]
pars$pd2v[P[[9]]]<-provparam$pd2v[9]

#Proportion in ICU dying not on ventilator
pars$pd2notv<-rep(0.22,N)
pars$pd2notv[P[[1]]]<-provparam$pd2notv[1]
pars$pd2notv[P[[2]]]<-provparam$pd2notv[2]
pars$pd2notv[P[[3]]]<-provparam$pd2notv[3]
pars$pd2notv[P[[4]]]<-provparam$pd2notv[4]
pars$pd2notv[P[[5]]]<-provparam$pd2notv[5]
pars$pd2notv[P[[6]]]<-provparam$pd2notv[6]
pars$pd2notv[P[[7]]]<-provparam$pd2notv[7]
pars$pd2notv[P[[8]]]<-provparam$pd2notv[8]
pars$pd2notv[P[[9]]]<-provparam$pd2notv[9]


#Behavioural heterogeneity factors
k<-rep(1,N)
k[P[[1]]]<-provparam$k[1]
k[P[[2]]]<-provparam$k[2]
k[P[[3]]]<-provparam$k[3]
k[P[[4]]]<-provparam$k[4]
k[P[[5]]]<-provparam$k[5]
k[P[[6]]]<-provparam$k[6]
k[P[[7]]]<-provparam$k[7]
k[P[[8]]]<-provparam$k[8]
k[P[[9]]]<-provparam$k[9]


#### Run scenario ####
#Define seeds
seedfac<-rep(10,N)
seedfac[P[[1]]]<-provparam$seedfac[1]
seedfac[P[[2]]]<-provparam$seedfac[2]
seedfac[P[[3]]]<-provparam$seedfac[3]
seedfac[P[[4]]]<-provparam$seedfac[4]
seedfac[P[[5]]]<-provparam$seedfac[5]
seedfac[P[[6]]]<-provparam$seedfac[6]
seedfac[P[[7]]]<-provparam$seedfac[7]
seedfac[P[[8]]]<-provparam$seedfac[8]
seedfac[P[[9]]]<-provparam$seedfac[9]

#Define transition and run function
covrates<-covrates_het
run<-run_o

#Run Deterministic Scenarios
scenID <- 1 #Choose scenario Use (1)
st <- Sys.time()
out1 <- run(pars, scenario[scenID,])
en <- Sys.time()
dt <- en - st

scenID <- 2 #Choose scenario Needs (2)
st <- Sys.time()
out2 <- run(pars, scenario[scenID,])
en <- Sys.time()
dt <- en - st

# District General Admissions Plot by Province
t=1:210
rows = c(3, 3, 3, 3, 3, 2, 3, 2, 3)
cols = c(3, 2, 2, 4, 2, 2, 2, 2, 2)
par(oma = c(2, 3, 2, 2)) # make room (i.e. the 4's) for the overall x and y axis titles
par(mar = c(3, 2, 2, 2)) # make the plots be closer together
for (p in c(1:9)){
  layout(matrix(c(1:(rows[p]*cols[p])), rows[p], cols[p], byrow = TRUE))
  for (d in (1:length(P[[p]]))) {
  plot(dtimes2[t],out2[[16]][t,P[[p]]][,d],type="l",col=1, main=districts$Code[which(districts$Province==names(P)[[p]])][d], cex=0.8, xaxt="n") #Need
  lines(dtimes2[t],out1[[16]][t,P[[p]]][,d],type="l",col=2, lty=2, cex=0.8, xaxt="n") #Use
    axis.Date(1, at = seq(dtimes2[1], dtimes2[max(t)], 4),format = "%d-%m", las = 2)
}
mtext(text = names(P)[[p]], side=3, outer = T)
}


